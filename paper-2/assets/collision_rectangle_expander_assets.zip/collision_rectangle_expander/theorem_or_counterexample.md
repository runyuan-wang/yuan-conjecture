# Sparse elastic rectangles: derivation, bounded-span no-go theorem, and the remaining lemma

## 1. Exact status

- **Original unrestricted sparse-expander proposition:** **OPEN**.
- **Rigorous outcome of this experiment:** **Success B for a specified subclass**. Any rectangle skeleton on the full grids `V_m` whose maximum incidence degree and side lengths are both bounded by absolute constants has normalized gap tending to zero. Thus every successful skeleton must use genuinely nonlocal rectangles.
- **Additional evidence:** four exact finite kernel certificates and **numerical support only** for a nonlocal residual-greedy sequence. Its four finite gaps are not an asymptotic theorem.
- Nothing here says that a skeleton can be extracted from an arbitrary Kakeya counterexample.

## 2. Elastic rectangle formula, independently derived

Let four equal-mass velocities satisfy momentum conservation

\[
v_1+v_2=v_3+v_4.
\]

Put

\[
a=v_1,\qquad p=v_3-v_1,\qquad q=v_4-v_1.
\]

Momentum then forces

\[
v_1=a,\quad v_3=a+p,\quad v_4=a+q,\quad v_2=a+p+q.
\]

The energy residual is

\[
\begin{aligned}
&|a|^2+|a+p+q|^2-|a+p|^2-|a+q|^2\\
&\hspace{35mm}=2p\cdot q.
\end{aligned}
\]

Consequently energy conservation is equivalent to `p·q=0`. Nondegeneracy is exactly `p != 0` and `q != 0`; then the four vertices are distinct. Conversely, every such orthogonal parallelogram satisfies both conservation laws.

For a scalar function `f` on the selected velocities, the rectangle gives the row

\[
\Delta_{a;p,q}f
=f(a)+f(a+p+q)-f(a+p)-f(a+q).
\]

Changing the choice of positive diagonal multiplies the row by `-1` and changes no kernel or spectrum.

## 3. The five compulsory and independent modes

For each rectangle,

\[
\Delta 1=0,
\qquad
\Delta x=\Delta y=\Delta z=0,
\qquad
\Delta |v|^2=2p\cdot q=0.
\]

Thus

\[
\mathcal K=\operatorname{span}\{1,x,y,z,|v|^2\}\subseteq\ker C.
\]

On every `V_m={-m,...,m}^3`, `m>=1`, these functions are independent. Evaluate them at

\[
(0,0,0),(1,0,0),(-1,0,0),(0,1,0),(0,0,1).
\]

In the column order `(1,x,y,z,|v|^2)`, the exact determinant is `2`. This explicit nondegeneracy condition is what the code and every certificate check.

## 4. Canonical complete-pool enumeration

Two unordered pairs `{u,v}` and `{r,s}` are the diagonals of the same Euclidean rectangle if and only if

\[
u+v=r+s,
\qquad
|u-v|^2=|r-s|^2.
\]

Indeed, equal midpoint gives a parallelogram and equal diagonal lengths make it a rectangle. Distinct pairs in one group cannot share one endpoint. Therefore the implementation:

1. lists every unordered vertex pair once;
2. groups pairs by `(u+v, |u-v|^2)`;
3. chooses every unordered pair of distinct diagonal pairs in each group;
4. sorts the two pairs, assigning `+,+` to the earlier and `-,-` to the later,

is a bijection with unordered nondegenerate rectangles. It neither uses nor permits periodic boundary conditions. The exact row checks were exhaustive at every reported scale.

## 5. Matrix and normalization

Let `R` be a set of distinct rectangles and let `C_R` be its integer row matrix. Every row has two `+1` and two `-1` entries and Euclidean norm `2`. Let

\[
d_v=\#\{R\ni v\},\qquad D_v=\operatorname{diag}(d_v).
\]

All final candidates have `d_v>0`. The canonical normalized operator in this experiment is

\[
A_R=\frac12 C_R D_v^{-1/2}.
\]

The factor `1/2` normalizes the unweighted row norm; column normalization removes local incidence load. Its compulsory nullspace is

\[
D_v^{1/2}\mathcal K.
\]

The reported gap is

\[
\gamma(R)=
\min_{\substack{x\perp D_v^{1/2}\mathcal K\\ \|x\|_2=1}}
\|A_Rx\|_2.
\]

If `ker C_R` is larger than `K`, then this quantity is zero. Equivalently, with `x=D_v^{1/2}f`,

\[
\gamma(R)^2
=
\frac14
\min_{f\notin\mathcal K}
\frac{\sum_{r\in R}|\Delta_r f|^2}
{\min_{h\in\mathcal K}\sum_{v}d_v|f(v)-h(v)|^2}.
\]

For comparison, the raw operator is `C_R`. Its singular values can grow merely by adding or repeating rows. `A_R` is unchanged by a uniform repetition of every row (aside from the fixed row normalization convention), while the raw singular values grow by the square root of the repetition factor. This is why a raw singular value is not called expansion here. Duplicated rectangles are forbidden in the actual candidates.

The combinatorial Laplacian convention without the row factor is

\[
L_{\rm comb}=D_v^{-1/2}C_R^TC_RD_v^{-1/2}=4A_R^TA_R.
\]

Hence its first positive eigenvalue is `4 gamma(R)^2`; the conventions differ only by this explicit fixed factor.

Finally, `dim ker_Q(C_R)=5` and `gamma(R)>=c` are logically different. Exact rank is algebraic. A positive finite gap is analytic, and a uniform lower bound over an infinite sequence is an asymptotic statement.

## 6. Rigorous Success B: bounded-side skeletons cannot expand

### Theorem (bounded-span no-go)

Let `m>=1`, `V_m={-m,...,m}^3`, and let `R_m` be any set of nondegenerate elastic rectangles on `V_m`. Assume

\[
1\le d_v\le D
\]

for every vertex and that, in every parameterization `(a,p,q)`,

\[
|p|\le L,\qquad |q|\le L.
\]

Define

\[
S_0=2m+1,
\quad
S_2=\sum_{t=-m}^{m}t^2
=\frac{m(m+1)(2m+1)}3,
\]

\[
S_4=\sum_{t=-m}^{m}t^4
=\frac{m(m+1)(2m+1)(3m^2+3m-1)}{15},
\]

and

\[
G_m=2S_0(S_0S_4-S_2^2).
\]

Then the normalized gap satisfies the explicit bound

\[
\boxed{
\gamma(R_m)
\le
\frac{L^2}{2}
\sqrt{\frac{D(2m+1)^3}{G_m}}
}
\]

and therefore

\[
\gamma(R_m)
\le
L^2\sqrt{\frac{45D}{32}}\,m^{-2}(1+o(1)).
\]

In particular, no class with absolute constants `D,L` has a uniform positive normalized gap.

### Proof

Take

\[
g(x,y,z)=x^2-y^2.
\]

By sign symmetry and exchange of `x,y`, `g` is orthogonal in unweighted `ell^2(V_m)` to all five functions in `K`:

\[
\sum g=\sum gx=\sum gy=\sum gz=\sum g|v|^2=0.
\]

Its exact squared norm is

\[
\|g\|_2^2
=\sum_{V_m}(x^2-y^2)^2
=2S_0(S_0S_4-S_2^2)=G_m.
\]

Let `h in K` be the weighted least-squares projection of `g` for the norm

\[
\|u\|_d^2=\sum_vd_v|u(v)|^2,
\]

and put `f=g-h`, `x=D_v^{1/2}f`. Then `x` is orthogonal to `D_v^{1/2}K`. Also, because every rectangle annihilates `h`,

\[
A_Rx=\frac12 C_Rf=\frac12 C_Rg.
\]

For one rectangle,

\[
\Delta_{a;p,q}g
=2(p_xq_x-p_yq_y),
\]

so Cauchy--Schwarz gives

\[
|\Delta g|
\le2\sqrt{p_x^2+p_y^2}\sqrt{q_x^2+q_y^2}
\le2L^2.
\]

Since `4|R_m|=sum_v d_v <= D|V_m|`,

\[
\|A_Rx\|_2^2
=\frac14\sum_{r\in R_m}|\Delta_rg|^2
\le |R_m|L^4
\le\frac{D|V_m|L^4}{4}.
\]

For the denominator, `d_v>=1` and the unweighted orthogonality of `g` to `K` imply

\[
\begin{aligned}
\|x\|_2^2
&=\sum_v d_v|g(v)-h(v)|^2\\
&\ge\sum_v|g(v)-h(v)|^2\\
&=\|g\|_2^2+\|h\|_2^2\\
&\ge G_m.
\end{aligned}
\]

The Rayleigh quotient gives the displayed finite bound. Using

\[
G_m\sim\frac{64}{45}m^7,
\qquad
|V_m|=(2m+1)^3\sim8m^3
\]

gives the asymptotic bound. `square`

### Scope

This proves a no-go theorem only for **bounded side length**. It does not rule out bounded-degree skeletons using long rectangles. The residual-greedy candidates do exactly that: their fraction of rows lying in a local `3x3x3` block falls from `0.2713` at `m=2` to `0.0205` at `m=5`.

If some vertices have degree zero, the experiment's positive-degree normalization gate already fails; such zero columns also obstruct the intended exact-five-kernel skeleton. The theorem is stated in the clean positive-degree case used by every final candidate.

## 7. Finite nonlocal evidence (not a theorem)

The primary sequence uses the residual-greedy method at target average incidence degree `6`. It is nonlocal, has maximum degree exactly `10` at every tested scale, and has no repeated rows.

| `m` | `N` | rectangles | avg degree | max degree | boundary vertices / `N` | rows touching boundary | normalized `gamma` | raw gap | normalized condition number | exact `dim ker_Q` |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 125 | 188 | 6.0160 | 10 | 0.7840 | 0.9787 | 0.137567 | 0.611217 | 5.7282 | 5 |
| 3 | 343 | 515 | 6.0058 | 10 | 0.6356 | 0.9262 | 0.108836 | 0.499871 | 7.5012 | 5 |
| 4 | 729 | 1,094 | 6.0027 | 10 | 0.5295 | 0.8720 | 0.107304 | 0.491519 | 7.5890 | 5 |
| 5 | 1,331 | 1,997 | 6.0015 | 10 | 0.4523 | 0.8272 | 0.104462 | 0.477680 | 7.7866 | 5 |

For each row of this table, exact verification provides:

1. exhaustive integer conservation/canonical-membership checks;
2. exact annihilation of the five integer modes;
3. anchor determinant `2`;
4. an explicitly listed `(N-5)x(N-5)` minor whose determinant is `1 mod 2`, hence is a nonzero integer;
5. independent full-rank screens modulo `2147483647` and `2147483629`.

Thus the kernel statements are exact finite certificates. The four gaps are floating-point discoveries with residual checks; they support, but do not prove, a uniform lower bound.

The residual sequence also survived the prescribed attacks at these scales:

- no articulation velocity, articulation rectangle node, or incidence bridge;
- soft-sweep crossing ratios `0.419, 0.397, 0.402, 0.400` (no emerging two-block bottleneck in this test);
- boundary soft mass divided by boundary vertex fraction `0.960, 0.995, 0.926, 1.054` (no growing boundary localization);
- degree-3 polynomial fit `R^2` decreases `0.128 -> 0.018`;
- additive product fit `R^2` decreases `0.147 -> 0.032`;
- coordinate-plane row fraction decreases `0.144 -> 0.052`;
- local-block row fraction decreases `0.271 -> 0.021`.

These diagnostics reject the tested finite failure mechanisms, not all possible asymptotic ones.

## 8. The attacked local construction

For the overlapping `3x3x3` block-glue method at target degree `24`, the normalized gaps are

\[
0.08336,\ 0.04583,\ 0.02996,\ 0.02026
\quad(m=2,3,4,5),
\]

while the degree-2 soft-mode fit approaches about `0.99` and the additive product fit approaches `0.999`. This numerically found the mode used in the theorem. The theorem, not the four-point trend, is what asymptotically rules out this class.

Coordinate-plane-only, single-axis product, and local-block restricted subfamilies were also ranked separately in every attack artifact; their additional kernels are reported exactly over `F_2`. The full surviving candidates were never replaced by these restricted families.

## 9. Smallest remaining open lemma

A clean remaining target, independent of Kakeya extraction, is the following.

> **Nonlocal rectangle-frame lemma.** There exist absolute `D<infinity`, `c>0`, an unbounded sequence `m_j`, and distinct elastic rectangles `R_{m_j}` on `V_{m_j}` such that `1<=d_v<=D` and, for every scalar `f`,
> \[
> \sum_{r\in R_{m_j}}|\Delta_rf|^2
> \ge
> 4c^2\min_{h\in\mathcal K}
> \sum_{v\in V_{m_j}}d_v|f(v)-h(v)|^2.
> \]

The inequality itself forces the real kernel to be exactly `K`, and because the rows and modes are rational it also gives the rational kernel statement. It is precisely the uniform nonlocal frame estimate missing from the finite experiment. The bounded-span theorem proves that any proof must exploit sides whose lengths grow with `m`; purely local rigidity-block gluing cannot establish it.

The four primary certificates are consistent with `D=10` and `c≈0.10`, but finite consistency is not proof of this lemma.

## 10. Structural stop

After the methods were fixed, `m=4` and `m=5` only enlarged scale; they produced no new construction or failure mechanism. The frozen two-round structural-stop rule therefore fired. No `m>5` brute force was run. The work moved to the theorem above rather than extrapolating more finite numbers.
