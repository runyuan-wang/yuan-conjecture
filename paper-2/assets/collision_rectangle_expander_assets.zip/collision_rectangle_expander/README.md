# Sparse elastic rectangle stress expander — independent experiment

## Bottom line in plain language

A collision rectangle says that the mixed second difference of a function on four velocities is zero. The five unavoidable solutions are the constant, the three velocity coordinates, and kinetic energy.

This run did **not** prove that a bounded-degree family with a size-independent spectral gap exists. The unrestricted proposition is **still open**.

It did prove one useful negative result:

> **Success B (limited class):** if both the number of rectangles touching each velocity and the Euclidean lengths of all rectangle sides stay bounded as the grid grows, the normalized gap is `O(m^-2)` and therefore tends to zero.

So a successful sparse skeleton, if one exists, must make essential use of long, nonlocal rectangles. Overlapping fixed-size local rigidity blocks cannot work.

The run also found a nonlocal residual-greedy family with maximum degree `10`. At `m=2,3,4,5`, its normalized gaps are

```text
0.137567, 0.108836, 0.107304, 0.104462.
```

At all four sizes, exact odd-minor certificates prove that the rational kernel is exactly the five collision invariants. These four gap values are **numerical support**, not an asymptotic theorem.

## Evidence levels

- **Rigorous theorem / Success B for a specified subclass:** bounded-side bounded-degree no-go theorem in `theorem_or_counterexample.md`.
- **Exact finite certificate:** rational kernel dimension `5` for the four primary candidates; see `results/certificates/`.
- **Numerical support:** normalized singular gaps and condition numbers at four finite sizes.
- **Still open:** a uniform nonlocal rectangle-frame inequality, and hence the original unrestricted hard-skeleton proposition.
- **Not studied/claimed:** extraction from an arbitrary Kakeya counterexample.

## Main files

- `theorem_or_counterexample.md` — definitions, normalization, full proof, finite table, and smallest remaining lemma.
- `generate_elastic_rectangles.py` — canonical full-pool enumerator.
- `search_sparse_rectangle_expander.py` — uniform, residual, reverse-delete, and block-glue searches.
- `verify_rectangle_kernel_exact.py` — exhaustive row audit, odd maximal minor, and two large-prime screens.
- `analyze_soft_modes.py` — all prescribed structural attacks.
- `validate_bounded_span_theorem.py` — independent arithmetic/Rayleigh checks of the theorem proof.
- `results/experiment_summary.json` — compact conclusion-oriented data.
- `results/raw_index.json` — paths, sizes, and hashes for raw data/logs.
- `FAILURE_LOG.md` — missing frozen inputs, command failures, and failed candidates.

## Normalization

For integer rectangle matrix `C` and incidence degree diagonal `D`, this run uses

```text
A = (1/2) C D^(-1/2).
```

The gap is the smallest singular value of `A` on the orthogonal complement of `D^(1/2){1,x,y,z,|v|^2}`. The combinatorial convention `D^(-1/2) C^T C D^(-1/2)` has gap eigenvalue `4*gap^2`. Raw `C` singular values are reported separately and are not called expansion.

## Minimal dependency-free rerun after unzipping

Python 3 plus NumPy is enough for this `m=1` smoke test. Run from this directory:

```bash
mkdir -p scratch/candidates scratch/attacks
PYTHONHASHSEED=0 python3 generate_elastic_rectangles.py \
  --m 1 --output scratch/pool_m1.json
PYTHONHASHSEED=0 python3 search_sparse_rectangle_expander.py \
  --m 1 --degrees 6 --methods residual_greedy --trials 1 \
  --seed-base 2026081400 --output-dir scratch/candidates \
  --summary scratch/search_m1.json
candidate=$(ls scratch/candidates/*.json)
PYTHONHASHSEED=0 python3 verify_rectangle_kernel_exact.py "$candidate" \
  --output scratch/exact_m1.json
PYTHONHASHSEED=0 python3 analyze_soft_modes.py "$candidate" \
  --output-dir scratch/attacks --summary scratch/attacks_m1.json
```

Expected key line:

```text
m1_residual_greedy_d6_t0_18e86df34c71: exact rank_Q=22, kernel_Q=5
```

The smoke test uses the NumPy dense spectral fallback and does not require SciPy.

## Full experiment environment

The host had Python `3.14.6` and NumPy `2.3.3`. SciPy was absent, so SciPy `1.16.1` was installed only into task-local `../.deps` and excluded from the delivery ZIP. The full commands prefixed

```bash
PYTHONHASHSEED=0 PYTHONPATH=../.deps python3 ...
```

The installation transcript is retained outside this clean delivery directory as `../dependency_install.log`; exact commands and resource records are in the task-root `REPORT.md`. No global/shared dependency or configuration was modified.

## Boundaries

- No periodic boundary was used.
- No rectangle was duplicated.
- Maximum degree, average degree, full degree histogram, boundary ratios, cuts, attacks, raw and normalized spectra are in candidate/attack JSON.
- The brute-force stop fired after `m=4` and `m=5` were consecutive scale-only rounds. No `m>5` search was run.
- The exact authoritative input ZIP was read only. No repository, GitHub state, credential, or unrelated path was modified.
