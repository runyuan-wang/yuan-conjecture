#!/usr/bin/env python3
"""Search bounded-degree elastic-rectangle skeletons by four distinct methods."""
from __future__ import annotations

import argparse
import math
import sys
import warnings
from pathlib import Path

import numpy as np

from rectangle_core import (
    atomic_json,
    candidate_basic_stats,
    environment,
    f2_rank,
    file_sha256,
    generate_pool,
    hash_rows,
    incidence_degrees,
    quotient_spectrum,
    utc_now,
)

METHODS = ("uniform_capped", "residual_greedy", "reverse_delete", "block_glue")


def target_rows(n: int, average_degree: float) -> int:
    return int(math.ceil(average_degree * n / 4.0))


def uniform_capped(pool: np.ndarray, n: int, count: int, cap: int,
                   rng: np.random.Generator) -> tuple[np.ndarray, dict]:
    perm = rng.permutation(len(pool))
    chosen = []
    deg = np.zeros(n, dtype=np.int32)
    for idx in perm:
        row = pool[idx]
        if np.all(deg[row] < cap):
            chosen.append(int(idx)); deg[row] += 1
            if len(chosen) == count:
                break
    if len(chosen) < count:
        raise RuntimeError(f"uniform capped sampler filled only {len(chosen)}/{count}")
    return np.asarray(chosen, dtype=np.int64), {
        "selection": "uniform random permutation followed by deterministic cap rejection",
        "permutation_entries_examined_at_most": int(len(perm)),
    }


def balanced_extend(pool: np.ndarray, n: int, count: int, cap: int,
                    rng: np.random.Generator, initial: np.ndarray | None = None,
                    eligible: np.ndarray | None = None, choices: int = 64) -> tuple[np.ndarray, dict]:
    universe = np.arange(len(pool), dtype=np.int64) if eligible is None else np.asarray(eligible, dtype=np.int64)
    chosen_mask = np.zeros(len(pool), dtype=bool)
    chosen = [] if initial is None else list(map(int, initial))
    if chosen:
        chosen_mask[np.asarray(chosen)] = True
    deg = incidence_degrees(n, pool[np.asarray(chosen, dtype=np.int64)]).astype(np.int32) if chosen else np.zeros(n, dtype=np.int32)
    retries = 0
    while len(chosen) < count:
        sample = universe[rng.integers(0, len(universe), size=choices)]
        sample = np.unique(sample)
        valid = sample[~chosen_mask[sample]]
        if len(valid):
            ok = np.all(deg[pool[valid]] < cap, axis=1)
            valid = valid[ok]
        if not len(valid):
            retries += 1
            if retries > 2000:
                # Portable deterministic fallback scan from a random offset.
                offset = int(rng.integers(0, len(universe)))
                valid_list = []
                for t in range(len(universe)):
                    idx = int(universe[(offset + t) % len(universe)])
                    if not chosen_mask[idx] and np.all(deg[pool[idx]] < cap):
                        valid_list.append(idx); break
                if not valid_list:
                    raise RuntimeError(f"balanced sampler filled only {len(chosen)}/{count}")
                valid = np.asarray(valid_list, dtype=np.int64)
            else:
                continue
        loads = deg[pool[valid]]
        # Power-of-choices load balancing; stable index tie break is deterministic.
        score = loads.sum(axis=1) + 2.0 * loads.max(axis=1)
        order = np.lexsort((valid, score))
        idx = int(valid[order[0]])
        chosen.append(idx); chosen_mask[idx] = True; deg[pool[idx]] += 1
    return np.asarray(chosen, dtype=np.int64), {
        "selection": "power-of-choices minimum current endpoint load under a hard cap",
        "choices_per_step": choices,
        "empty_sample_retries": retries,
        "eligible_pool_count": int(len(universe)),
    }


def residual_greedy(pool: np.ndarray, vs: np.ndarray, count: int, cap: int,
                    rng: np.random.Generator, seed: int) -> tuple[np.ndarray, dict]:
    n = len(vs)
    initial_count = min(count, max(n, int(math.floor(0.72 * count))))
    selected, initial_meta = balanced_extend(pool, n, initial_count, cap, rng, choices=48)
    chosen = np.zeros(len(pool), dtype=bool); chosen[selected] = True
    history = []
    rounds = 0
    while len(selected) < count:
        rows = pool[selected]
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            spec = quotient_spectrum(vs, rows, normalized=True, small_k=2,
                                     tol=8e-6, seed=seed + rounds)
        x = np.asarray(spec.pop("soft_vector_normalized_coordinates"), dtype=np.float64)
        d = incidence_degrees(n, rows).astype(np.float64)
        inv = np.zeros(n); inv[d > 0] = 1.0 / np.sqrt(d[d > 0])
        f = x * inv
        sample_count = min(len(pool), max(20_000, 80 * n))
        sample = np.unique(rng.integers(0, len(pool), size=sample_count))
        sample = sample[~chosen[sample]]
        if len(sample):
            sample = sample[np.all(d[pool[sample]] < cap, axis=1)]
        if not len(sample):
            # Complete using balanced load if the residual sample hits the cap wall.
            selected, tail_meta = balanced_extend(pool, n, count, cap, rng, initial=selected, choices=128)
            history.append({"round": rounds, "fallback": "balanced_extend", "tail_meta": tail_meta})
            break
        r = pool[sample]
        residual = f[r[:, 0]] + f[r[:, 1]] - f[r[:, 2]] - f[r[:, 3]]
        load = d[r].sum(axis=1)
        # Residual annihilates the current soft mode; a small load bonus avoids cores.
        score = residual * residual + 0.03 / (1.0 + load)
        order = np.lexsort((sample, -score))
        want = min(count - len(selected), max(1, int(math.ceil((count - initial_count) / 3))))
        added = []
        for pos in order:
            idx = int(sample[pos]); row = pool[idx]
            if chosen[idx] or np.any(d[row] >= cap):
                continue
            chosen[idx] = True; d[row] += 1; added.append(idx)
            if len(added) >= want:
                break
        if not added:
            selected, tail_meta = balanced_extend(pool, n, count, cap, rng, initial=selected, choices=128)
            history.append({"round": rounds, "fallback": "balanced_extend_no_add", "tail_meta": tail_meta})
            break
        selected = np.concatenate((selected, np.asarray(added, dtype=np.int64)))
        history.append({
            "round": rounds,
            "pre_add_rectangle_count": int(len(rows)),
            "pre_add_gap_singular_value": spec["gap_singular_value"],
            "pre_add_small_eigenvalues": spec["small_quotient_eigenvalues_AtA"],
            "sample_count_after_filters": int(len(sample)),
            "added": len(added),
            "warning_messages": [str(w.message) for w in caught],
        })
        rounds += 1
        if rounds > 8:
            selected, tail_meta = balanced_extend(pool, n, count, cap, rng, initial=selected, choices=128)
            history.append({"round": rounds, "fallback": "round_limit", "tail_meta": tail_meta})
            break
    return selected, {"selection": "balanced seed then batches maximizing current normalized soft-mode residual", "initial": initial_meta, "history": history}


def reverse_delete(pool: np.ndarray, n: int, count: int, cap: int,
                   rng: np.random.Generator) -> tuple[np.ndarray, dict]:
    perm = rng.permutation(len(pool))
    rank, basis_in_perm = f2_rank(pool[perm], n, return_basis_indices=True)
    expected = n - 5
    if rank < expected:
        raise RuntimeError(f"full pool F2 rank {rank} < expected {expected}")
    basis = perm[np.asarray(basis_in_perm[:expected], dtype=np.int64)]
    if len(basis) > count:
        raise RuntimeError("target count smaller than exact reverse-delete basis")
    selected, meta = balanced_extend(pool, n, count, cap, rng, initial=basis, choices=128)
    return selected, {
        "selection": "randomized full-pool reverse deletion to an exact F2 row basis, then low-load restoration",
        "full_pool_rows": int(len(pool)),
        "full_pool_f2_rank": int(rank),
        "basis_rows_retained": int(len(basis)),
        "restoration": meta,
    }


def local_block_indices(pool: np.ndarray, vs: np.ndarray, chunk: int = 250_000) -> np.ndarray:
    pieces = []
    for start in range(0, len(pool), chunk):
        r = pool[start:start + chunk]
        xyz = vs[r]
        spans = xyz.max(axis=1) - xyz.min(axis=1)
        pieces.append(np.flatnonzero(np.all(spans <= 2, axis=1)) + start)
    return np.concatenate(pieces).astype(np.int64)


def make_candidate(method: str, pool: np.ndarray, vs: np.ndarray, degree: float,
                   seed: int, reverse_limit: int) -> tuple[np.ndarray | None, dict]:
    n = len(vs); count = target_rows(n, degree); rng = np.random.default_rng(seed)
    cap = max(int(math.ceil(1.55 * degree)), int(math.ceil(degree + 3)))
    if method == "uniform_capped":
        cap = max(cap, int(math.ceil(2.0 * degree)))
        sel, meta = uniform_capped(pool, n, count, cap, rng)
    elif method == "residual_greedy":
        sel, meta = residual_greedy(pool, vs, count, cap, rng, seed)
    elif method == "reverse_delete":
        m = round((n ** (1 / 3) - 1) / 2)
        if m > reverse_limit:
            return None, {"skipped": True, "reason": f"full-pool reverse-delete frozen at m<={reverse_limit} by resource discipline"}
        sel, meta = reverse_delete(pool, n, count, cap, rng)
    elif method == "block_glue":
        eligible = local_block_indices(pool, vs)
        if len(eligible) < count:
            return None, {"skipped": True, "reason": f"local block pool has only {len(eligible)} rows < target {count}"}
        sel, meta = balanced_extend(pool, n, count, cap, rng, eligible=eligible, choices=96)
        meta.update({
            "selection": "rows from overlapping 3x3x3 local rigidity blocks, glued through shared velocity vertices; power-of-choices thinning",
            "local_block_pool_count": int(len(eligible)),
            "local_definition": "coordinate span of all four vertices <=2 in each axis",
        })
    else:
        raise ValueError(method)
    sel = np.unique(sel)
    if len(sel) != count:
        raise RuntimeError(f"selection has {len(sel)} unique rows, expected {count}")
    sel.sort()
    return pool[sel], {"hard_incidence_cap": cap, "target_rectangle_count": count, **meta}


def spectrum_without_vector(spec: dict) -> tuple[dict, list[float]]:
    spec = dict(spec)
    vector = spec.pop("soft_vector_normalized_coordinates")
    return spec, vector


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--m", type=int, required=True)
    ap.add_argument("--degrees", default="6,8,12,16,24")
    ap.add_argument("--methods", default=",".join(METHODS))
    ap.add_argument("--seed-base", type=int, default=2026081400)
    ap.add_argument("--trials", type=int, default=1)
    ap.add_argument("--reverse-delete-max-m", type=int, default=3)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--summary", type=Path, required=True)
    args = ap.parse_args()
    degrees = [float(x) for x in args.degrees.split(",") if x]
    methods = [x for x in args.methods.split(",") if x]
    if any(x not in METHODS for x in methods):
        raise ValueError(f"methods must be in {METHODS}")

    vs, pool, pool_meta = generate_pool(args.m)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    attempts = []
    best = None
    for mi, method in enumerate(methods):
        for di, degree in enumerate(degrees):
            for trial in range(args.trials):
                seed = args.seed_base + args.m * 100_000 + mi * 10_000 + di * 100 + trial
                try:
                    rows, selection_meta = make_candidate(method, pool, vs, degree, seed, args.reverse_delete_max_m)
                    if rows is None:
                        attempts.append({"method": method, "target_average_degree": degree, "trial": trial, "seed": seed, **selection_meta})
                        continue
                    basic = candidate_basic_stats(vs, rows, args.m)
                    rank2 = f2_rank(rows, len(vs))
                    with warnings.catch_warnings(record=True) as caught:
                        warnings.simplefilter("always")
                        normalized_full = quotient_spectrum(vs, rows, normalized=True, small_k=6,
                                                            tol=2e-7, seed=seed)
                    normalized, soft = spectrum_without_vector(normalized_full)
                    # Raw scale is meaningful only when a positive quotient gap is seen.
                    if normalized["gap_singular_value"] > 1e-9:
                        with warnings.catch_warnings(record=True) as caught_raw:
                            warnings.simplefilter("always")
                            raw_full = quotient_spectrum(vs, rows, normalized=False, small_k=3,
                                                         tol=3e-7, seed=seed + 1)
                        raw, _ = spectrum_without_vector(raw_full)
                        raw_warnings = [str(w.message) for w in caught_raw]
                    else:
                        raw = {"not_run": True, "reason": "normalized quotient gap numerically zero"}
                        raw_warnings = []
                    candidate_hash = hash_rows(rows)
                    cid = f"m{args.m}_{method}_d{degree:g}_t{trial}_{candidate_hash[:12]}"
                    cpath = args.output_dir / f"{cid}.json"
                    candidate = {
                        "schema": "sparse_elastic_rectangle_candidate.v1",
                        "candidate_id": cid,
                        "candidate_sha256": candidate_hash,
                        "created_utc": utc_now(),
                        "m": args.m,
                        "vertex_count": int(len(vs)),
                        "vertices": "implicit lexicographic {-m,...,m}^3; index=((x+m)(2m+1)+(y+m))(2m+1)+(z+m)",
                        "rectangle_row": "+1 at first diagonal pair; -1 at second; canonical pool order",
                        "pool_sha256": pool_meta["pool_sha256"],
                        "pool_rectangle_count": pool_meta["rectangle_count"],
                        "method": method,
                        "target_average_degree": degree,
                        "trial": trial,
                        "seed": seed,
                        "selection_metadata": selection_meta,
                        "basic_statistics": basic,
                        "exact_f2_rank": int(rank2),
                        "exact_f2_full_rank_n_minus_5": bool(rank2 == len(vs) - 5),
                        "normalized_spectrum": normalized,
                        "raw_row_matrix_spectrum": raw,
                        "spectral_warning_messages": [str(w.message) for w in caught],
                        "raw_spectral_warning_messages": raw_warnings,
                        "soft_vector_normalized_coordinates": soft,
                        "environment": environment(),
                        "script_sha256": file_sha256(__file__),
                        "rectangles": rows.tolist(),
                    }
                    atomic_json(cpath, candidate)
                    record = {
                        "candidate_id": cid,
                        "candidate_file": cpath.name,
                        "method": method,
                        "target_average_degree": degree,
                        "trial": trial,
                        "seed": seed,
                        "rectangle_count": len(rows),
                        "average_degree": basic["average_incidence_degree"],
                        "max_degree": basic["max_incidence_degree"],
                        "zero_degree_vertices": basic["zero_degree_vertices"],
                        "component_count": basic["two_section_component_count"],
                        "boundary_touch_fraction": basic["rectangles_touching_boundary_fraction"],
                        "f2_rank": int(rank2),
                        "expected_rank": len(vs) - 5,
                        "normalized_gap_sigma": normalized["gap_singular_value"],
                        "normalized_gap_lambda": normalized["gap_eigenvalue"],
                        "normalized_condition_number": normalized["quotient_condition_number"],
                        "raw_gap_sigma": raw.get("gap_singular_value"),
                        "candidate_sha256": candidate_hash,
                    }
                    attempts.append(record)
                    key = (rank2 == len(vs) - 5, normalized["gap_singular_value"], -basic["max_incidence_degree"])
                    if best is None or key > best[0]:
                        best = (key, record)
                    print(f"{cid}: rank2={rank2}/{len(vs)-5} gap={normalized['gap_singular_value']:.6g} maxdeg={basic['max_incidence_degree']}", flush=True)
                except Exception as exc:
                    attempts.append({
                        "method": method, "target_average_degree": degree, "trial": trial, "seed": seed,
                        "failed": True, "error_type": type(exc).__name__, "error": str(exc),
                    })
                    print(f"FAILED m={args.m} {method} d={degree:g}: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
    summary = {
        "schema": "sparse_elastic_rectangle_search_run.v1",
        "created_utc": utc_now(),
        "command": [Path(sys.argv[0]).name, *sys.argv[1:]],
        "m": args.m,
        "degrees": degrees,
        "methods": methods,
        "trials": args.trials,
        "seed_base": args.seed_base,
        "environment": environment(),
        "script_sha256": file_sha256(__file__),
        "pool": {k: v for k, v in pool_meta.items() if k != "full_pool_incidence_degree"},
        "attempts": attempts,
        "best_candidate": None if best is None else best[1],
        "resource_stop": "No m>5 is authorized by this run; after m=4 and m=5 are scale-only rounds the frozen structural-stop rule fires.",
    }
    atomic_json(args.summary, summary)
    print(f"summary={args.summary} best={None if best is None else best[1]['candidate_id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
