#!/usr/bin/env python3
"""Enumerate the complete non-periodic elastic-rectangle pool on V_m."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from rectangle_core import (
    anchor_determinant,
    atomic_json,
    environment,
    file_sha256,
    generate_pool,
    row_formula_check,
    utc_now,
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--m", type=int, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--save-pool-npy", type=Path, default=None,
                    help="optional binary pool cache (not needed for verification)")
    args = ap.parse_args()

    vs, rows, meta = generate_pool(args.m)
    # Exhaustive integer formula audit, not a sample.
    failures = []
    for idx, row in enumerate(rows):
        ok, detail = row_formula_check(vs, row)
        if not ok:
            failures.append({"row_index": idx, "row": row.tolist(), "detail": detail})
            if len(failures) >= 10:
                break
    if failures:
        raise AssertionError(f"rectangle formula audit failed: {failures}")
    if len(np.unique(rows, axis=0)) != len(rows):
        raise AssertionError("canonical pool contains duplicates")

    meta.update({
        "generated_utc": utc_now(),
        "command": [Path(sys.argv[0]).name, *sys.argv[1:]],
        "environment": environment(),
        "script_sha256": file_sha256(__file__),
        "exact_formula_rows_checked": int(len(rows)),
        "exact_formula_failures": 0,
        "known_mode_anchor_points": [[0, 0, 0], [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, 0, 1]],
        "known_mode_anchor_determinant": anchor_determinant(args.m),
        "known_modes_linearly_independent": anchor_determinant(args.m) != 0,
    })
    atomic_json(args.output, meta)
    if args.save_pool_npy is not None:
        args.save_pool_npy.parent.mkdir(parents=True, exist_ok=True)
        np.save(args.save_pool_npy, rows, allow_pickle=False)
    print(f"m={args.m} vertices={len(vs)} rectangles={len(rows)} sha256={meta['pool_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
