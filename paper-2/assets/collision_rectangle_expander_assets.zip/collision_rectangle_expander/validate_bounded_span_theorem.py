#!/usr/bin/env python3
"""Independent finite arithmetic/numerical checks of the bounded-span proof formulas."""
from __future__ import annotations

import argparse
import glob
from pathlib import Path

import numpy as np

from rectangle_core import atomic_json, environment, file_sha256, incidence_degrees, load_candidate, mode_matrix, utc_now, vertices


def moments(m: int):
    s0 = 2 * m + 1
    s2 = m * (m + 1) * (2 * m + 1) // 3
    s4 = m * (m + 1) * (2 * m + 1) * (3 * m * m + 3 * m - 1) // 15
    g = 2 * s0 * (s0 * s4 - s2 * s2)
    return s0, s2, s4, g


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=Path("results"))
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    moment_checks = []
    for m in range(1, 11):
        vs = vertices(m).astype(np.int64)
        gv = vs[:, 0] ** 2 - vs[:, 1] ** 2
        K = mode_matrix(vs, dtype=np.int64)
        formula = moments(m)[3]
        brute = int(gv @ gv)
        dots = (K.T @ gv).tolist()
        moment_checks.append({"m": m, "G_formula": formula, "G_bruteforce": brute, "equal": formula == brute, "unweighted_mode_inner_products": dots})
        if formula != brute or any(dots):
            raise AssertionError(f"moment/orthogonality failure m={m}")

    candidate_checks = []
    for m in range(2, 6):
        path = Path(glob.glob(str(args.results / f"candidates_m{m}" / f"m{m}_block_glue_d24_*.json"))[0])
        obj, vs, rows = load_candidate(path)
        v64 = vs.astype(np.int64)
        u, r, s = v64[rows[:, 0]], v64[rows[:, 2]], v64[rows[:, 3]]
        p, q = r - u, s - u
        psq, qsq = np.sum(p * p, axis=1), np.sum(q * q, axis=1)
        L2 = int(max(psq.max(), qsq.max()))  # L^2
        g = v64[:, 0] ** 2 - v64[:, 1] ** 2
        delta_direct = g[rows[:, 0]] + g[rows[:, 1]] - g[rows[:, 2]] - g[rows[:, 3]]
        delta_formula = 2 * (p[:, 0] * q[:, 0] - p[:, 1] * q[:, 1])
        if not np.array_equal(delta_direct, delta_formula):
            raise AssertionError("Delta g identity failed")
        if np.max(np.abs(delta_direct)) > 2 * L2:
            raise AssertionError("Delta g side bound failed")
        d = incidence_degrees(len(vs), rows).astype(np.float64)
        K = mode_matrix(vs)
        gram = K.T @ (d[:, None] * K)
        rhs = K.T @ (d * g)
        hcoef = np.linalg.solve(gram, rhs)
        f = g - K @ hcoef
        x = np.sqrt(d) * f
        test_sigma = 0.5 * float(np.linalg.norm(delta_direct) / np.linalg.norm(x))
        s0, _, _, G = moments(m)
        D = int(d.max())
        theorem_bound = (L2 / 2.0) * np.sqrt(D * (s0 ** 3) / G)
        observed = float(obj["normalized_spectrum"]["gap_singular_value"])
        if observed > test_sigma * (1 + 2e-5) or test_sigma > theorem_bound * (1 + 1e-12):
            raise AssertionError("Rayleigh/theorem inequality chain failed")
        candidate_checks.append({
            "m": m, "candidate_id": obj["candidate_id"], "D": D, "L_squared": L2,
            "observed_smallest_sigma": observed,
            "g_weighted_projected_Rayleigh_sigma": test_sigma,
            "closed_form_theorem_upper_bound": float(theorem_bound),
            "inequality_chain_verified": True,
            "max_abs_Delta_g": int(np.max(np.abs(delta_direct))),
            "two_L_squared": 2 * L2,
        })
    out = {
        "schema": "bounded_span_theorem_validation.v1", "created_utc": utc_now(),
        "exact_moment_and_orthogonality_checks": moment_checks,
        "block_candidate_inequality_checks": candidate_checks,
        "all_checks_passed": True, "environment": environment(), "script_sha256": file_sha256(__file__),
    }
    atomic_json(args.output, out)
    print(f"validated exact moments m=1..10 and theorem inequality chain on {len(candidate_checks)} block candidates")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
