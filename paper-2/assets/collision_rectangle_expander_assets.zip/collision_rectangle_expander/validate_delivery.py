#!/usr/bin/env python3
"""Final internal consistency and clean-delivery validator."""
from __future__ import annotations

import argparse
import ast
import json
import math
from pathlib import Path

import numpy as np

from rectangle_core import atomic_json, environment, f2_rank, file_sha256, hash_rows, load_candidate, row_formula_check, utc_now

REQUIRED = [
    "README.md", "theorem_or_counterexample.md", "generate_elastic_rectangles.py",
    "search_sparse_rectangle_expander.py", "verify_rectangle_kernel_exact.py",
    "analyze_soft_modes.py", "FAILURE_LOG.md", "literature_dedup.md",
    "results/experiment_summary.json", "results/raw_index.json",
]
EXPECTED_POOLS = {
    2: (125, 12222, "517bc73644b5ae20a5a7271f4e7540036734481fb0d1668bb32720e939b9f8b2"),
    3: (343, 136686, "95f9606574e66fda26e032fe56fca7dafd4a03730de4cc0c7b5adb182d04e2aa"),
    4: (729, 819264, "a5d078c5a138a84c31597ee31bbdf7afcd95b61fc1fd49b815cafb0f4d9e86e1"),
    5: (1331, 3391860, "d0361a0878d30e6dfa9371f9dd956735e5c45cd3ea4405e7a9197ed40154d9c0"),
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path("."))
    ap.add_argument("--output", type=Path)
    ap.add_argument("--verify-raw-index", action="store_true")
    args = ap.parse_args()
    root = args.root.resolve()
    checks = {}
    missing = [p for p in REQUIRED if not (root / p).is_file()]
    if missing: raise AssertionError(f"missing required files: {missing}")
    checks["required_files"] = True
    caches = [str(p.relative_to(root)) for p in root.rglob("__pycache__")]
    symlinks = [str(p.relative_to(root)) for p in root.rglob("*") if p.is_symlink()]
    if caches or symlinks: raise AssertionError({"caches": caches, "symlinks": symlinks})
    checks["no_cache_or_symlink"] = True

    pyfiles = sorted(root.glob("*.py"))
    for p in pyfiles: ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
    checks["python_ast_parse"] = len(pyfiles)

    json_files = sorted((root / "results").rglob("*.json"))
    for p in json_files: json.loads(p.read_text(encoding="utf-8"))
    checks["json_parse_count"] = len(json_files)

    for m, expected in EXPECTED_POOLS.items():
        obj = json.loads((root / f"results/pool_m{m}.json").read_text())
        got = (obj["vertex_count"], obj["rectangle_count"], obj["pool_sha256"])
        if got != expected or obj["exact_formula_failures"] != 0 or obj["known_mode_anchor_determinant"] != 2:
            raise AssertionError(f"pool mismatch m={m}: {got}")
    checks["pool_identities"] = True

    candidates = []
    survivors = []
    for m in range(2, 6):
        for path in sorted((root / f"results/candidates_m{m}").glob("*.json")):
            obj, vs, rows = load_candidate(path)
            if hash_rows(rows) != obj["candidate_sha256"]: raise AssertionError(f"candidate hash {path}")
            if len(np.unique(rows, axis=0)) != len(rows): raise AssertionError(f"duplicates {path}")
            # Exhaustive row formula audit for every delivered candidate.
            for row in rows:
                if not row_formula_check(vs, row)[0]: raise AssertionError(f"formula {path}")
            rank2 = f2_rank(rows, len(vs))
            if rank2 != obj["exact_f2_rank"]: raise AssertionError(f"rank2 {path}")
            if not math.isfinite(obj["normalized_spectrum"]["gap_singular_value"]): raise AssertionError(f"spectrum {path}")
            candidates.append(path)
            if rank2 == len(vs) - 5: survivors.append(obj["candidate_id"])
    checks["candidate_count"] = len(candidates)
    checks["survivor_count"] = len(survivors)

    attacks = {p.stem for p in (root / "results/attacks").glob("*.json")}
    absent_attacks = sorted(set(survivors) - attacks)
    if absent_attacks: raise AssertionError(f"survivors without attacks: {absent_attacks}")
    for m in range(2, 6):
        a = json.loads((root / f"results/attacks_m{m}.json").read_text())
        if a["failures"] or not a["all_surviving_candidates_attacked_without_failure"]:
            raise AssertionError(f"attack failure m={m}")
    checks["every_survivor_attacked"] = True

    for m in range(2, 6):
        cert = json.loads((root / f"results/certificates/exact_kernel_m{m}_residual_d6.json").read_text())
        if cert["kernel_dimension_over_Q"] != 5 or cert["rank_over_Q"] != cert["vertex_count"] - 5:
            raise AssertionError(f"cert rank m={m}")
        minor = cert["odd_maximal_minor_certificate"]
        if minor["minor_determinant_mod_2"] != 1 or minor["minor_order"] != cert["vertex_count"] - 5:
            raise AssertionError(f"minor m={m}")
        if len(cert["large_prime_rank_screens"]) != 2 or not all(x["full_n_minus_5"] for x in cert["large_prime_rank_screens"]):
            raise AssertionError(f"prime screens m={m}")
    checks["four_exact_certificates"] = True

    theorem = json.loads((root / "results/bounded_span_theorem_validation.json").read_text())
    if not theorem["all_checks_passed"]: raise AssertionError("theorem validator")
    checks["bounded_span_theorem_validation"] = True

    forbidden_hits = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".md", ".py", ".json", ".txt"}:
            text = p.read_text(encoding="utf-8", errors="strict")
            private_prefix = "/" + "Users/"  # split so this validator does not trip its own scan
            if private_prefix in text: forbidden_hits.append(str(p.relative_to(root)))
    if forbidden_hits: raise AssertionError(f"absolute private paths in delivery: {forbidden_hits}")
    checks["no_absolute_private_paths_in_text"] = True

    if args.verify_raw_index:
        index = json.loads((root / "results/raw_index.json").read_text())
        for rec in index["files"]:
            p = root / "results" / rec["path"]
            if not p.is_file() or p.stat().st_size != rec["bytes"] or file_sha256(p) != rec["sha256"]:
                raise AssertionError(f"raw index mismatch: {rec['path']}")
        checks["raw_index_entries_verified"] = len(index["files"])

    out = {
        "schema": "collision_rectangle_delivery_validation.v1", "validated_utc": utc_now(),
        "checks": checks, "all_checks_passed": True, "environment": environment(),
    }
    if args.output: atomic_json(args.output, out)
    print(json.dumps(out, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
