#!/usr/bin/env python3
"""Exact finite kernel certificate for a sparse elastic-rectangle candidate."""
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np

from rectangle_core import (
    DEFAULT_PRIMES,
    anchor_determinant,
    anchor_indices,
    atomic_json,
    environment,
    f2_rank,
    file_sha256,
    hash_rows,
    load_candidate,
    mode_matrix,
    modular_rank_sparse,
    row_formula_check,
    utc_now,
)


def is_prime_trial(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for d in range(3, math.isqrt(n) + 1, 2):
        if n % d == 0:
            return False
    return True


def canonical_pool_row(vs: np.ndarray, row: np.ndarray) -> bool:
    i, j, k, l = map(int, row)
    if not (0 <= i < j < len(vs) and 0 <= k < l < len(vs) and (i, j) < (k, l)):
        return False
    u, v, r, s = map(lambda x: x.astype(np.int64), (vs[i], vs[j], vs[k], vs[l]))
    return bool(np.all(u + v == r + s) and (u - v) @ (u - v) == (r - s) @ (r - s))


def f2_minor(rows: np.ndarray, n: int) -> dict:
    pivots: dict[int, int] = {}
    sources: dict[int, int] = {}
    for ridx, row in enumerate(np.asarray(rows, dtype=np.int64)):
        x = 0
        for c in row:
            x ^= 1 << int(c)
        while x:
            p = x.bit_length() - 1
            if p in pivots:
                x ^= pivots[p]
            else:
                pivots[p] = x; sources[p] = ridx; break
    cols = sorted(pivots, reverse=True)
    selected_rows = [sources[p] for p in cols]
    # Recheck the stated square submatrix itself, not merely the whole matrix.
    colmap = {c: j for j, c in enumerate(cols)}
    restricted = []
    for ridx in selected_rows:
        bits = 0
        for c in rows[ridx]:
            if int(c) in colmap:
                bits ^= 1 << colmap[int(c)]
        restricted.append(bits)
    q: dict[int, int] = {}
    for bits in restricted:
        while bits:
            p = bits.bit_length() - 1
            if p in q: bits ^= q[p]
            else: q[p] = bits; break
    return {
        "rank": len(pivots),
        "minor_row_indices": selected_rows,
        "minor_column_indices": cols,
        "minor_order": len(cols),
        "minor_rank_mod_2_recheck": len(q),
        "minor_determinant_mod_2": 1 if len(q) == len(cols) else 0,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate", type=Path)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--primes", default=",".join(map(str, DEFAULT_PRIMES)))
    ap.add_argument("--skip-large-primes", action="store_true",
                    help="small packaged check only; not accepted for final certificates")
    args = ap.parse_args()
    obj, vs, rows = load_candidate(args.candidate)
    n = len(vs); expected = n - 5
    if len(np.unique(rows, axis=0)) != len(rows):
        raise AssertionError("duplicate candidate rows")
    if hash_rows(rows) != obj["candidate_sha256"]:
        raise AssertionError("candidate row hash mismatch")

    bad = []
    for ridx, row in enumerate(rows):
        ok, detail = row_formula_check(vs, row)
        canonical = canonical_pool_row(vs, row)
        if not ok or not canonical:
            bad.append({"row_index": ridx, "row": row.tolist(), "formula": detail, "canonical": canonical})
            if len(bad) >= 10: break
    if bad:
        raise AssertionError(f"bad rows: {bad}")

    K = mode_matrix(vs, dtype=np.int64)
    residual = np.zeros((len(rows), 5), dtype=np.int64)
    residual[:, :] = K[rows[:, 0]] + K[rows[:, 1]] - K[rows[:, 2]] - K[rows[:, 3]]
    max_known_residual = int(np.abs(residual).max(initial=0))
    if max_known_residual != 0:
        raise AssertionError("known modes not annihilated")
    ad = anchor_determinant(int(obj["m"]))
    if ad == 0:
        raise AssertionError("known modes not independent")

    minor = f2_minor(rows, n)
    rank2_again = f2_rank(rows, n)
    if minor["rank"] != rank2_again:
        raise AssertionError("F2 implementations disagree")
    if minor["minor_determinant_mod_2"] != 1 or minor["minor_order"] != expected:
        raise AssertionError(f"no maximal odd minor: rank2={minor['rank']}, expected={expected}")

    primes = [int(x) for x in args.primes.split(",") if x]
    prime_results = []
    if not args.skip_large_primes:
        for p in primes:
            if p < 1_000_000_000 or not is_prime_trial(p):
                raise ValueError(f"modulus is not a verified large prime: {p}")
            rankp = modular_rank_sparse(rows, n, p, stop_at=expected)
            prime_results.append({"prime": p, "rank": rankp, "full_n_minus_5": rankp == expected})
            if rankp != expected:
                raise AssertionError(f"rank mod {p} is {rankp}, expected {expected}")

    cert = {
        "schema": "exact_elastic_rectangle_kernel_certificate.v1",
        "created_utc": utc_now(),
        "candidate_file": args.candidate.name,
        "candidate_id": obj["candidate_id"],
        "candidate_sha256": obj["candidate_sha256"],
        "m": int(obj["m"]),
        "vertex_count": n,
        "rectangle_count": int(len(rows)),
        "integer_rows_formula_and_canonical_pool_membership_all_verified": True,
        "candidate_rows_unique": True,
        "known_mode_order": ["1", "x", "y", "z", "x^2+y^2+z^2"],
        "known_mode_integer_residual_max_abs": max_known_residual,
        "known_mode_anchor_vertex_indices": anchor_indices(int(obj["m"])),
        "known_mode_anchor_points": [[0, 0, 0], [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, 0, 1]],
        "known_mode_anchor_determinant_exact": ad,
        "known_modes_linearly_independent_over_Q": True,
        "rank_upper_bound_over_Q_from_known_kernel": expected,
        "odd_maximal_minor_certificate": minor,
        "large_prime_rank_screens": prime_results,
        "rank_over_Q": expected,
        "kernel_dimension_over_Q": 5,
        "known_modes_span_entire_rational_kernel": True,
        "exact_argument": "Five independent integer kernel columns give rank_Q<=N-5. The stated (N-5)x(N-5) integer minor has determinant 1 modulo 2, hence a nonzero integer determinant and rank_Q>=N-5.",
        "large_primes_are_independent_screens_not_the_rational_proof": True,
        "command": [Path(sys.argv[0]).name, *sys.argv[1:]],
        "environment": environment(),
        "script_sha256": file_sha256(__file__),
    }
    atomic_json(args.output, cert)
    print(f"{obj['candidate_id']}: exact rank_Q={expected}, kernel_Q=5, odd minor order={expected}, large-prime screens={prime_results}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
