# Final narrow direct-precedent deduplication

## Scope and method

Performed exactly one narrow web search after the mathematical/computational conclusion was coherent. This was not a literature review.

- Date: 2026-08-15 UTC
- Engine: DuckDuckGo
- Exact query: `"orthogonal rectangles" "mixed second difference" spectral gap bounded degree lattice`
- Returned results: 10
- No result page was opened, because the frozen contract allowed only a narrow final check and the result titles/snippets already showed no exact match.

## Direct correspondence

**No direct correspondence found in this one-query check.** None of the ten returned titles/snippets concerned the exact object studied here: a signed four-vertex elastic-rectangle matrix on integer velocity grids, with kernel `span{1,x,y,z,|v|^2}`, vertex-incidence normalization, and a bounded-side `O(m^-2)` no-gap theorem tested by `x^2-y^2`.

This is only “not found in the bounded query,” not a priority or novelty claim.

## Adjacent tools returned

1. **Discrete Laplace operators** — adjacent general language for lattice operators and low-frequency test functions; not the signed orthogonal-rectangle operator or its five-mode kernel.
   - Search result: “Discrete Laplace operator,” Wikipedia, `https://en.wikipedia.org/wiki/Discrete_Laplace_operator`.
2. **Generic spectral-gap definitions / graph expansion** — adjacent terminology only; not a direct theorem about elastic rectangles.
   - Search result: “Spectral gap,” Wikipedia, `https://en.wikipedia.org/wiki/Spectral_gap`.
   - Search result: bounded-degree expander construction discussion on Theoretical Computer Science Stack Exchange.
3. **Quantum-spin / circuit spectral gaps and detectability lemmas** — use bounded-degree graphs or lattice finite-size criteria, but concern unrelated positive semidefinite Hamiltonians rather than this collision-constraint matrix.
4. **Spectral rectangles in domain optimization** — the word “rectangles” refers to geometric domains and Laplacian eigenvalues, not additive/elastic velocity rectangles.

## Boundary

The authoritative local ZIP remains the scientific authority for this experiment. This narrow external check did not replace, revise, or supplement any frozen prior result. A broader scholarly search could reveal related finite-difference or frame inequalities, but it was intentionally not performed.
