#!/usr/bin/env python3
"""Shared deterministic primitives for elastic rectangles.

Only NumPy is mandatory.  SciPy is used when available for sparse spectra; a
small dense fallback keeps the packaged m=1/m=2 validation self-contained.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import struct
import sys
import time
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Iterable, Iterator, Sequence

import numpy as np

try:  # Optional; the experiment used an isolated task-local SciPy wheel.
    import scipy
    from scipy import sparse
    from scipy.sparse.linalg import eigsh, lobpcg
except Exception:  # pragma: no cover - exercised by packaged dependency-free check
    scipy = None
    sparse = None
    eigsh = None
    lobpcg = None

POOL_HASH_DOMAIN = b"elastic-rectangle-pool-v1\0uint32be(+,+,-,-)\0"
CANDIDATE_HASH_DOMAIN = b"elastic-rectangle-candidate-v1\0uint32be(+,+,-,-)\0"
DEFAULT_PRIMES = (2_147_483_647, 2_147_483_629)


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def environment() -> dict:
    return {
        "python": sys.version,
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": None if scipy is None else scipy.__version__,
        "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
    }


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: str | Path, obj: object) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def vertices(m: int) -> np.ndarray:
    """Lexicographic V_m = {-m,...,m}^3, x then y then z."""
    if m < 1:
        raise ValueError("m must be >=1")
    return np.asarray(
        [(x, y, z) for x in range(-m, m + 1)
                   for y in range(-m, m + 1)
                   for z in range(-m, m + 1)],
        dtype=np.int32,
    )


def vertex_index(m: int, xyz: Sequence[int]) -> int:
    side = 2 * m + 1
    x, y, z = map(int, xyz)
    if min(x, y, z) < -m or max(x, y, z) > m:
        raise ValueError("vertex outside V_m")
    return ((x + m) * side + (y + m)) * side + (z + m)


def diagonal_groups(vs: np.ndarray) -> dict[tuple[int, int, int, int], list[tuple[int, int]]]:
    """Group unordered vertex pairs by (twice midpoint, squared diagonal length)."""
    groups: dict[tuple[int, int, int, int], list[tuple[int, int]]] = defaultdict(list)
    n = len(vs)
    for i in range(n - 1):
        u = vs[i]
        for j in range(i + 1, n):
            w = vs[j]
            s = u + w
            d = u - w
            key = (int(s[0]), int(s[1]), int(s[2]), int(d @ d))
            groups[key].append((i, j))
    return groups


def pool_count_from_groups(groups: dict) -> int:
    return sum(len(g) * (len(g) - 1) // 2 for g in groups.values())


def generate_pool(m: int) -> tuple[np.ndarray, np.ndarray, dict]:
    """Return vertices, canonical rectangle rows, and deterministic pool metadata.

    A row `(i,j,k,l)` has +1 at the lexicographically earlier diagonal pair
    `(i,j)` and -1 at `(k,l)`.  Pairs in one group have the same midpoint and
    diagonal length, hence form a rectangle.  This is a bijective de-dup rule.
    """
    vs = vertices(m)
    groups = diagonal_groups(vs)
    count = pool_count_from_groups(groups)
    rows = np.empty((count, 4), dtype=np.int32)
    h = hashlib.sha256(POOL_HASH_DOMAIN)
    degree = np.zeros(len(vs), dtype=np.int64)
    pos = 0
    group_sizes = Counter()
    # Dict insertion order is deterministic because vertices/pairs are deterministic,
    # but sorting makes the byte specification independent of that language detail.
    for key in sorted(groups):
        pairs = sorted(groups[key])
        group_sizes[len(pairs)] += 1
        for a in range(len(pairs) - 1):
            i, j = pairs[a]
            for b in range(a + 1, len(pairs)):
                k, l = pairs[b]
                row = (i, j, k, l)
                rows[pos] = row
                h.update(struct.pack(">4I", *row))
                degree[list(row)] += 1
                pos += 1
    assert pos == count
    del groups
    boundary = np.any(np.abs(vs) == m, axis=1)
    row_boundary = np.any(boundary[rows], axis=1)
    meta = {
        "schema": "elastic_rectangle_pool.v1",
        "m": m,
        "vertex_count": int(len(vs)),
        "rectangle_count": int(count),
        "pool_sha256": h.hexdigest(),
        "pool_hash_encoding": "SHA256(domain || concatenated uint32 big-endian canonical (+,+,-,-) rows)",
        "full_pool_incidence_degree": degree.tolist(),
        "full_pool_degree_min": int(degree.min()),
        "full_pool_degree_max": int(degree.max()),
        "full_pool_degree_mean": float(degree.mean()),
        "boundary_vertex_count": int(boundary.sum()),
        "boundary_vertex_fraction": float(boundary.mean()),
        "rectangles_touching_boundary": int(row_boundary.sum()),
        "rectangles_touching_boundary_fraction": float(row_boundary.mean()),
        "diagonal_group_size_histogram": {str(k): int(v) for k, v in sorted(group_sizes.items())},
        "canonical_rule": "group unordered diagonals by equal endpoint sum and squared length; sort pairs; earlier pair gets +,+ and later pair -,-",
        "periodic_boundary": False,
    }
    return vs, rows, meta


def hash_rows(rows: np.ndarray) -> str:
    h = hashlib.sha256(CANDIDATE_HASH_DOMAIN)
    for row in np.asarray(rows, dtype=np.int64):
        h.update(struct.pack(">4I", *map(int, row)))
    return h.hexdigest()


def row_formula_check(vs: np.ndarray, row: Sequence[int]) -> tuple[bool, dict]:
    i, j, k, l = map(int, row)
    u, v, r, s = (vs[i].astype(np.int64), vs[j].astype(np.int64),
                  vs[k].astype(np.int64), vs[l].astype(np.int64))
    momentum = u + v - r - s
    energy = int(u @ u + v @ v - r @ r - s @ s)
    p, q = r - u, s - u
    distinct = len({i, j, k, l}) == 4
    return bool(distinct and np.all(momentum == 0) and energy == 0 and p @ q == 0 and np.any(p) and np.any(q)), {
        "momentum_residual": momentum.tolist(),
        "energy_residual": energy,
        "p_dot_q": int(p @ q),
        "distinct": distinct,
    }


def mode_matrix(vs: np.ndarray, dtype=np.float64) -> np.ndarray:
    v = vs.astype(dtype)
    return np.column_stack((np.ones(len(v), dtype=dtype), v, np.sum(v * v, axis=1)))


def anchor_indices(m: int) -> list[int]:
    # Evaluation of (1,x,y,z,|v|^2) at these five points has determinant -2.
    return [vertex_index(m, p) for p in [(0, 0, 0), (1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, 0, 1)]]


def anchor_determinant(m: int) -> int:
    vs = vertices(m)
    a = mode_matrix(vs, dtype=np.int64)[anchor_indices(m)]
    # Exact 5x5 Bareiss.
    return bareiss_det(a.tolist())


def bareiss_det(a: list[list[int]]) -> int:
    a = [list(map(int, row)) for row in a]
    n = len(a)
    if any(len(row) != n for row in a):
        raise ValueError("square matrix required")
    if n == 0:
        return 1
    sign, prev = 1, 1
    for k in range(n - 1):
        pivot = next((r for r in range(k, n) if a[r][k]), None)
        if pivot is None:
            return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            sign *= -1
        pk = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                a[i][j] = (a[i][j] * pk - a[i][k] * a[k][j]) // prev
            a[i][k] = 0
        prev = pk
    return sign * a[n - 1][n - 1]


def incidence_degrees(n: int, rows: np.ndarray) -> np.ndarray:
    d = np.zeros(n, dtype=np.int64)
    if len(rows):
        np.add.at(d, np.asarray(rows).ravel(), 1)
    return d


def boundary_stats(vs: np.ndarray, rows: np.ndarray, m: int) -> dict:
    b = np.any(np.abs(vs) == m, axis=1)
    touch = np.any(b[np.asarray(rows)], axis=1) if len(rows) else np.zeros(0, dtype=bool)
    allb = np.all(b[np.asarray(rows)], axis=1) if len(rows) else np.zeros(0, dtype=bool)
    return {
        "boundary_vertex_count": int(b.sum()),
        "boundary_vertex_fraction": float(b.mean()),
        "rectangles_touching_boundary": int(touch.sum()),
        "rectangles_touching_boundary_fraction": float(touch.mean()) if len(touch) else 0.0,
        "rectangles_all_boundary_vertices": int(allb.sum()),
        "rectangles_all_boundary_vertices_fraction": float(allb.mean()) if len(allb) else 0.0,
    }


def degree_stats(n: int, rows: np.ndarray) -> dict:
    d = incidence_degrees(n, rows)
    hist = Counter(map(int, d))
    dmin = int(d.min()) if len(d) else 0
    dmax = int(d.max()) if len(d) else 0
    return {
        "rectangle_count": int(len(rows)),
        "average_incidence_degree": float(d.mean()),
        "max_incidence_degree": dmax,
        "min_incidence_degree": dmin,
        "zero_degree_vertices": int(np.count_nonzero(d == 0)),
        "degree_histogram": {str(k): int(v) for k, v in sorted(hist.items())},
        "degree_gini": float(gini(d)),
        "top_one_percent_incidence_share": float(top_share(d, 0.01)),
    }


def gini(x: np.ndarray) -> float:
    x = np.sort(np.asarray(x, dtype=np.float64))
    if len(x) == 0 or x.sum() == 0:
        return 0.0
    return float((2 * np.dot(np.arange(1, len(x) + 1), x) / (len(x) * x.sum())) - (len(x) + 1) / len(x))


def top_share(x: np.ndarray, fraction: float) -> float:
    x = np.sort(np.asarray(x, dtype=np.float64))[::-1]
    if x.sum() == 0:
        return 0.0
    k = max(1, math.ceil(len(x) * fraction))
    return float(x[:k].sum() / x.sum())


def signed_matrix(n: int, rows: np.ndarray, normalized: bool = False):
    rows = np.asarray(rows, dtype=np.int64)
    m = len(rows)
    rr = np.repeat(np.arange(m, dtype=np.int64), 4)
    cc = rows.ravel()
    data = np.tile(np.asarray([1.0, 1.0, -1.0, -1.0]), m)
    if normalized:
        d = incidence_degrees(n, rows).astype(np.float64)
        inv = np.zeros(n)
        inv[d > 0] = 1.0 / np.sqrt(d[d > 0])
        data *= 0.5 * inv[cc]
    if sparse is not None:
        return sparse.csr_matrix((data, (rr, cc)), shape=(m, n))
    out = np.zeros((m, n), dtype=np.float64)
    out[rr, cc] = data
    return out


def _constraint_basis(vs: np.ndarray, degrees: np.ndarray, normalized: bool) -> np.ndarray:
    k = mode_matrix(vs)
    if normalized:
        k = np.sqrt(degrees.astype(np.float64))[:, None] * k
    # Drop numerical dependencies defensively (not expected for m>=1).
    q, r = np.linalg.qr(k, mode="reduced")
    keep = np.abs(np.diag(r)) > 1e-11
    return q[:, keep]


def quotient_spectrum(vs: np.ndarray, rows: np.ndarray, normalized: bool = True,
                      small_k: int = 6, tol: float = 2e-7, seed: int = 0) -> dict:
    """Small quotient eigenvalues of A^T A and largest eigenvalue.

    normalized=True uses A=(1/2) C D^{-1/2}; its canonical gap is the
    smallest quotient singular value.  Constraints are D^{1/2} times the five
    invariants.  Residual norms are reported and the smallest vector returned.
    """
    n = len(vs)
    d = incidence_degrees(n, rows)
    A = signed_matrix(n, rows, normalized=normalized)
    L = A.T @ A
    Y = _constraint_basis(vs, d, normalized)
    qdim = n - Y.shape[1]
    k = max(1, min(small_k, qdim - 1 if qdim > 1 else 1))
    rng = np.random.default_rng(seed)
    if sparse is not None and n > 400:
        X = rng.normal(size=(n, k))
        X -= Y @ (Y.T @ X)
        # lobpcg handles an explicitly constrained quotient without forming a dense basis.
        vals, vecs, history = lobpcg(L, X, Y=Y, largest=False, tol=tol,
                                     maxiter=250, retResidualNormsHistory=True)
        order = np.argsort(vals)
        vals, vecs = np.asarray(vals)[order], np.asarray(vecs)[:, order]
        residuals = np.asarray(history[-1])[order]
        largest = float(eigsh(L, k=1, which="LA", return_eigenvectors=False, tol=tol)[0])
        solver = "scipy.sparse.lobpcg_constrained"
    else:
        if n > 500:
            raise RuntimeError("SciPy is required for spectra with n>500")
        Ld = np.asarray(L if sparse is None else L.toarray(), dtype=np.float64)
        # Complete QR gives an explicit orthonormal complement.
        Qfull, _ = np.linalg.qr(Y, mode="complete")
        Z = Qfull[:, Y.shape[1]:]
        evals, evecs = np.linalg.eigh(Z.T @ Ld @ Z)
        vals = evals[:k]
        vecs = Z @ evecs[:, :k]
        residuals = np.asarray([np.linalg.norm(Ld @ vecs[:, i] - vals[i] * vecs[:, i]) for i in range(k)])
        largest = float(evals[-1]) if len(evals) else 0.0
        solver = "numpy.linalg.eigh_explicit_quotient"
    vals[np.abs(vals) < 1e-13] = 0.0
    gap_eigenvalue = float(vals[0])
    gap_sigma = math.sqrt(max(0.0, gap_eigenvalue))
    max_sigma = math.sqrt(max(0.0, largest))
    return {
        "normalization": "A=(1/2) C D^{-1/2}" if normalized else "A=C",
        "small_quotient_eigenvalues_AtA": [float(x) for x in vals],
        "small_quotient_singular_values": [math.sqrt(max(0.0, float(x))) for x in vals],
        "gap_eigenvalue": gap_eigenvalue,
        "gap_singular_value": gap_sigma,
        "largest_eigenvalue": largest,
        "largest_singular_value": max_sigma,
        "quotient_condition_number": (max_sigma / gap_sigma if gap_sigma > 0 else None),
        "residual_norms": [float(x) for x in residuals],
        "solver": solver,
        "known_mode_constraint_dimension": int(Y.shape[1]),
        "soft_vector_normalized_coordinates": vecs[:, 0].tolist(),
    }


def f2_rank(rows: np.ndarray, n: int, return_basis_indices: bool = False):
    """Exact rank over F_2 using Python integer bitsets."""
    pivots: dict[int, int] = {}
    pivot_sources: dict[int, int] = {}
    for ridx, row in enumerate(np.asarray(rows, dtype=np.int64)):
        x = 0
        for c in row:
            x ^= 1 << int(c)
        while x:
            p = x.bit_length() - 1
            if p in pivots:
                x ^= pivots[p]
            else:
                pivots[p] = x
                pivot_sources[p] = ridx
                break
    if return_basis_indices:
        return len(pivots), [pivot_sources[p] for p in sorted(pivots, reverse=True)]
    return len(pivots)


def modular_rank_sparse(rows: np.ndarray, n: int, prime: int, stop_at: int | None = None) -> int:
    """Exact sparse row elimination over a prime field.

    Intended for certification after F_2 has already found full rank.  Rows begin
    4-sparse; dict arithmetic retains sparsity as long as possible.
    """
    pivots: dict[int, dict[int, int]] = {}
    target = n if stop_at is None else stop_at
    for raw in np.asarray(rows, dtype=np.int64):
        r = {int(raw[0]): 1, int(raw[1]): 1, int(raw[2]): prime - 1, int(raw[3]): prime - 1}
        while r:
            c = min(r)
            a = r[c]
            if c not in pivots:
                inv = pow(a, prime - 2, prime)
                if a != 1:
                    r = {j: (v * inv) % prime for j, v in r.items()}
                pivots[c] = r
                if len(pivots) >= target:
                    return len(pivots)
                break
            base = pivots[c]
            factor = a
            for j, v in base.items():
                nv = (r.get(j, 0) - factor * v) % prime
                if nv:
                    r[j] = nv
                elif j in r:
                    del r[j]
    return len(pivots)


def components_and_cuts(n: int, rows: np.ndarray) -> dict:
    """Connectivity/cut diagnostics of the rectangle 2-section graph."""
    adj = [set() for _ in range(n)]
    edge_set = set()
    for row in np.asarray(rows, dtype=np.int64):
        rr = list(map(int, row))
        for a in range(4):
            for b in range(a + 1, 4):
                u, v = sorted((rr[a], rr[b]))
                adj[u].add(v); adj[v].add(u); edge_set.add((u, v))
    seen = np.zeros(n, dtype=bool)
    sizes = []
    for root in range(n):
        if seen[root]:
            continue
        q = [root]; seen[root] = True; size = 0
        for u in q:
            size += 1
            for v in adj[u]:
                if not seen[v]:
                    seen[v] = True; q.append(v)
        sizes.append(size)
    # Deterministic two-sweep lower bound on diameter in the largest component.
    def bfs_far(start: int):
        dist = {start: 0}; q = deque([start]); far = start
        while q:
            u = q.popleft(); far = u
            for v in sorted(adj[u]):
                if v not in dist:
                    dist[v] = dist[u] + 1; q.append(v)
        far = max(dist, key=lambda x: (dist[x], -x))
        return far, dist[far]
    nonisolated = [i for i in range(n) if adj[i]]
    diam_lb = 0
    if nonisolated:
        f, _ = bfs_far(nonisolated[0]); _, diam_lb = bfs_far(f)
    return {
        "two_section_component_count": len(sizes),
        "two_section_component_sizes_desc": sorted(sizes, reverse=True),
        "two_section_edge_count": len(edge_set),
        "two_sweep_diameter_lower_bound": int(diam_lb),
    }


def candidate_basic_stats(vs: np.ndarray, rows: np.ndarray, m: int) -> dict:
    out = degree_stats(len(vs), rows)
    out.update(boundary_stats(vs, rows, m))
    out.update(components_and_cuts(len(vs), rows))
    # Incidence bipartite graph cycle rank E_b-(V_b-components), E_b=4R.
    # Compute bipartite components cheaply by union-find.
    parent = np.arange(len(vs) + len(rows), dtype=np.int64)
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = int(parent[x])
        return x
    def union(a, b):
        a, b = find(a), find(b)
        if a != b: parent[b] = a
    for r, row in enumerate(np.asarray(rows, dtype=np.int64)):
        for v in row: union(int(v), len(vs) + r)
    active = set()
    for v in range(len(vs)): active.add(find(v))
    for r in range(len(rows)): active.add(find(len(vs) + r))
    out["incidence_bipartite_component_count"] = len(active)
    out["incidence_bipartite_cycle_rank"] = int(4 * len(rows) - (len(vs) + len(rows)) + len(active))
    return out


def load_candidate(path: str | Path) -> tuple[dict, np.ndarray, np.ndarray]:
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    m = int(obj["m"])
    vs = vertices(m)
    rows = np.asarray(obj["rectangles"], dtype=np.int32)
    if rows.ndim != 2 or rows.shape[1] != 4:
        raise ValueError("candidate rectangles must be Mx4")
    return obj, vs, rows
