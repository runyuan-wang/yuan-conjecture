# FAILURE LOG

Failures are retained even when later corrected.

## F001 — Prescribed latest files are absent from the exact authoritative ZIP

- **When:** input-audit stage.
- **Gate:** Frozen `BRIEF.md` asks for full reads of `affine_agreement_tertiary_route_2026-08-13.md`, `plucker_realizability_routing_audit_2026-08-13.md`, and all `realizable_*` / `minimal_realizable_*` programs, results, and certificates.
- **Observed:** The exact 166,934-byte, SHA-256-verified ZIP has 39 members; none of those names/patterns is present. Its internal manifest covers exactly the other 38 members and also contains no such entries. `INPUT_RECEIPT.json` is the mechanical evidence.
- **Handling:** Did not substitute an older public-repository file for frozen authority. Read the available final ledger section and proof-route matrix, and treat the black-box statements frozen directly in `BRIEF.md` as context. This is an input-package incompleteness, not evidence against those prior results.

## F002 — First filename-pattern shell used a Bash-only builtin under zsh

- **Command issue:** A diagnostic used `compgen -G`; the host shell was zsh, so four `command not found` messages appeared even though a trailing sorted listing made the overall exit status zero.
- **Impact:** No files were changed and no scientific conclusion relied on `compgen`. Absence was independently established from the complete 39-member receipt/list and later Python validation.
- **Correction:** Use Python/`pathlib.glob` or portable `find` for later checks; inspect stderr even when exit code is zero.

## F003 — Shell policy rejected a compound unit-test wrapper

- **Observed:** A proposed command combined environment exports, recursive cleanup of a unit-output directory, the m=1 search, and inline JSON assertions. The shell policy rejected it before execution, naming the cleanup/wrapper commands.
- **Impact:** No command ran and no file was changed by the rejected call.
- **Correction:** Removed cleanup (the directory did not exist), used a single environment-prefixed experiment command, then a separate bounded JSON validation command. Both succeeded.

## F004 — zsh `status` is read-only in the first m=3 timing wrapper

- **Observed:** The m=3 enumerator itself completed successfully and wrote its JSON/stdout/stderr, but the wrapper then tried `status=$?`; zsh rejected assignment to its read-only `status` parameter, so the shell call exited 1.
- **Impact:** No scientific output was lost or corrupted. Direct JSON validation showed 343 vertices, 136,686 rectangles, zero formula failures, and the expected deterministic pool hash; the preserved timing log showed normal completion.
- **Correction:** Later timing wrappers use `command && inspect` and never assign zsh's reserved `status` variable.

## F005 — Low-density uniform random candidates can fail the exact kernel gate

- **Observed:** Uniform capped candidates failed the exact F2 `N-5` rank screen at `(m,d)=(3,6),(4,6),(5,6),(5,8),(5,16)` (the last has rank 1325/1326). Tiny LOBPCG values on some rank-deficient cases are numerical zero, not positive gaps.
- **Impact:** These candidates were classified as pre-attack non-survivors and are not used as positive evidence. Their raw JSON remains present.
- **Correction:** Residual-greedy candidates passed the exact gate at every tested m and degree; all surviving candidates were attacked. No claim is made that uniform constant-degree sampling works without conditioning/repair.

## F006 — First two clean-delivery validation attempts failed safely

- **Attempt 1:** The validator detected `__pycache__`, recreated by a postprocessing run after an earlier cleanup. It stopped before writing a success artifact.
- **Attempt 2:** After cache removal, the absolute-private-path scanner detected its own literal test string in `validate_delivery.py`; this was a self-trigger, not leaked path data.
- **Correction:** Split the sentinel string in source, disabled bytecode writes, and overwrote the redirected failure logs with the successful run. The final exhaustive run passed all gates: 70 candidates checked, 65 survivors attacked, four exact certificates, 166 JSON files parsed, no cache/symlink, and no absolute private path in delivery text.
