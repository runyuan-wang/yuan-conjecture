#!/usr/bin/env python3
"""Build separated compact summary and raw-artifact index from experiment JSON."""
from __future__ import annotations

import argparse
import glob
import json
from pathlib import Path

from rectangle_core import atomic_json, environment, file_sha256, utc_now


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=Path("results"))
    ap.add_argument("--summary", type=Path, required=True)
    ap.add_argument("--raw-index", type=Path, required=True)
    args = ap.parse_args()
    root = args.results
    pools = {}
    all_candidates = []
    all_methods = {}
    attack_counts = {}
    for m in range(2, 6):
        p = read(root / f"pool_m{m}.json")
        pools[str(m)] = {k: p[k] for k in [
            "vertex_count", "rectangle_count", "pool_sha256", "full_pool_degree_min",
            "full_pool_degree_max", "full_pool_degree_mean", "boundary_vertex_fraction",
            "rectangles_touching_boundary_fraction", "exact_formula_rows_checked",
            "known_mode_anchor_determinant",
        ]}
        s = read(root / f"search_m{m}.json")
        for a in s["attempts"]:
            if "candidate_id" not in a: continue
            rec = {"m": m, **a}
            all_candidates.append(rec)
            all_methods.setdefault(a["method"], {}).setdefault(str(a["target_average_degree"]), []).append({
                "m": m, "gap_sigma": a["normalized_gap_sigma"], "f2_rank": a["f2_rank"],
                "expected_rank": a["expected_rank"], "max_degree": a["max_degree"],
            })
        atk = read(root / f"attacks_m{m}.json")
        attack_counts[str(m)] = {
            "input": atk["input_candidate_count"], "attacked": atk["surviving_candidates_attacked"],
            "skipped_pre_attack_non_survivors": len(atk["pre_attack_non_survivors_skipped"]),
            "failures": len(atk["failures"]),
        }

    primary, local = [], []
    for m in range(2, 6):
        cp = Path(glob.glob(str(root / f"candidates_m{m}" / f"m{m}_residual_greedy_d6_*.json"))[0])
        c = read(cp); a = read(root / "attacks" / f"{c['candidate_id']}.json")
        b, ns, rs = c["basic_statistics"], c["normalized_spectrum"], c["raw_row_matrix_spectrum"]
        cert = root / "certificates" / f"exact_kernel_m{m}_residual_d6.json"
        z = read(cert)
        primary.append({
            "m": m, "N": c["vertex_count"], "rectangles": len(c["rectangles"]),
            "average_degree": b["average_incidence_degree"], "max_degree": b["max_incidence_degree"],
            "min_degree": b["min_incidence_degree"], "degree_histogram": b["degree_histogram"],
            "boundary_vertex_fraction": b["boundary_vertex_fraction"],
            "rectangles_touching_boundary_fraction": b["rectangles_touching_boundary_fraction"],
            "normalized_gap_sigma": ns["gap_singular_value"],
            "normalized_gap_lambda": ns["gap_eigenvalue"],
            "normalized_condition_number": ns["quotient_condition_number"],
            "raw_gap_sigma": rs["gap_singular_value"],
            "exact_rank_Q": z["rank_over_Q"], "exact_kernel_dimension_Q": z["kernel_dimension_over_Q"],
            "odd_minor_order": z["odd_maximal_minor_certificate"]["minor_order"],
            "large_prime_screens": z["large_prime_rank_screens"],
            "candidate_file": str(cp.relative_to(root)),
            "certificate_file": str(cert.relative_to(root)),
            "attack_file": f"attacks/{c['candidate_id']}.json",
            "attack_highlights": {
                "coordinate_plane_fraction": a["geometry_and_single_direction_attack"]["coordinate_plane_rectangle_fraction"],
                "local_block_fraction": a["geometry_and_single_direction_attack"]["local_3x3x3_block_rectangle_fraction"],
                "soft_sweep_crossing_ratio": a["two_large_blocks_sparse_cut_attack"]["soft_sweep"]["crossing_per_smaller_incidence_volume"],
                "boundary_mass_over_boundary_fraction": a["diagnostic_feature_scores_not_probabilities"]["boundary"],
                "degree3_polynomial_R2": a["near_polynomial_mode_attack"]["degree_3_fit"]["unweighted_R2"],
                "axis_additive_product_R2": a["ruled_carrier_KxK_product_attack"]["axis_additive_ANOVA_R2"],
                "articulation_velocity_vertices": a["hinge_tree_long_chain_cycle_attack"]["articulation_velocity_vertices"],
                "incidence_bridges": a["hinge_tree_long_chain_cycle_attack"]["incidence_bridges"],
            },
        })
        lp = Path(glob.glob(str(root / f"candidates_m{m}" / f"m{m}_block_glue_d24_*.json"))[0])
        lc = read(lp); la = read(root / "attacks" / f"{lc['candidate_id']}.json")
        local.append({
            "m": m, "N": lc["vertex_count"], "max_degree": lc["basic_statistics"]["max_incidence_degree"],
            "normalized_gap_sigma": lc["normalized_spectrum"]["gap_singular_value"],
            "degree2_polynomial_R2": la["near_polynomial_mode_attack"]["degree_2_fit"]["unweighted_R2"],
            "axis_additive_product_R2": la["ruled_carrier_KxK_product_attack"]["axis_additive_ANOVA_R2"],
            "candidate_file": str(lp.relative_to(root)),
        })

    summary = {
        "schema": "elastic_rectangle_experiment_summary.v1", "created_utc": utc_now(),
        "evidence_label": "MAIN PROPOSITION OPEN; SUCCESS B for the bounded-side bounded-degree subclass; exact finite certificates and numerical support for nonlocal residual candidates",
        "pool_scales": pools,
        "primary_nonlocal_residual_degree6_sequence": primary,
        "method_degree_scale_trends": all_methods,
        "bounded_local_block_degree24_sequence": local,
        "surviving_candidate_attack_coverage": attack_counts,
        "structural_stop": {
            "fired": True,
            "reason": "m=4 and m=5 were consecutive scale-only rounds with no new candidate structure; no m>5 enumeration/search was run",
        },
        "rigorous_result": {
            "label": "Success B (specified subclass)",
            "class": "V_m full grids, maximum incidence degree D, every rectangle side length <=L, with D,L absolute constants",
            "conclusion": "the canonical normalized gap is at most (L^2/2)*sqrt(D*N_m/G_m)=O_D,L(m^-2), where G_m=sum_{V_m}(x^2-y^2)^2; hence no uniform positive gap",
        },
        "not_claimed": [
            "finite gaps prove an asymptotic expander",
            "the primary residual sequence has a uniform gap",
            "any skeleton can be extracted from an arbitrary Kakeya counterexample",
            "absence of an expander implies a grain/plany branch",
        ],
        "environment": environment(),
    }
    atomic_json(args.summary, summary)

    raw_files = sorted(p for p in root.rglob("*") if p.is_file() and p not in {args.summary, args.raw_index})
    index = {
        "schema": "elastic_rectangle_raw_index.v1", "created_utc": utc_now(),
        "root": "results", "file_count": len(raw_files),
        "files": [{"path": str(p.relative_to(root)), "bytes": p.stat().st_size, "sha256": file_sha256(p)} for p in raw_files],
    }
    atomic_json(args.raw_index, index)
    print(f"summary={args.summary} raw_index={args.raw_index} files={len(raw_files)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
