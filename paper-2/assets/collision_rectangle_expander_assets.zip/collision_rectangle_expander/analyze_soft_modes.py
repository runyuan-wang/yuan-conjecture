#!/usr/bin/env python3
"""Adversarial structural and soft-mode attacks on every surviving candidate."""
from __future__ import annotations

import argparse
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

from rectangle_core import (
    atomic_json,
    candidate_basic_stats,
    environment,
    f2_rank,
    file_sha256,
    incidence_degrees,
    load_candidate,
    mode_matrix,
    utc_now,
)


def primitive_direction(v: np.ndarray) -> tuple[int, int, int]:
    a = list(map(int, v))
    g = 0
    for x in a: g = math.gcd(g, abs(x))
    if g: a = [x // g for x in a]
    for x in a:
        if x:
            if x < 0: a = [-y for y in a]
            break
    return tuple(a)


def rectangle_geometry(vs: np.ndarray, rows: np.ndarray) -> dict:
    u = vs[rows[:, 0]].astype(np.int64)
    r = vs[rows[:, 2]].astype(np.int64)
    s = vs[rows[:, 3]].astype(np.int64)
    p, q = r - u, s - u
    psq, qsq = np.sum(p * p, axis=1), np.sum(q * q, axis=1)
    dirs = Counter()
    for z in np.concatenate((p, q), axis=0): dirs[primitive_direction(z)] += 1
    max_dir, max_count = max(dirs.items(), key=lambda kv: (kv[1], kv[0]))
    allxyz = vs[rows]
    constant_axes = np.all(allxyz == allxyz[:, :1, :], axis=1)
    coordinate_plane = np.any(constant_axes, axis=1)
    p_axis = np.count_nonzero(p, axis=1) == 1
    q_axis = np.count_nonzero(q, axis=1) == 1
    axis_product = p_axis & q_axis
    spans = allxyz.max(axis=1) - allxyz.min(axis=1)
    local_span2 = np.all(spans <= 2, axis=1)
    return {
        "p": p, "q": q, "psq": psq, "qsq": qsq,
        "coordinate_plane_mask": coordinate_plane,
        "axis_product_mask": axis_product,
        "local_span2_mask": local_span2,
        "summary": {
            "side_length_squared_min": int(min(psq.min(), qsq.min())),
            "side_length_squared_max": int(max(psq.max(), qsq.max())),
            "coordinate_plane_rectangle_count": int(coordinate_plane.sum()),
            "coordinate_plane_rectangle_fraction": float(coordinate_plane.mean()),
            "axis_aligned_product_rectangle_count": int(axis_product.sum()),
            "axis_aligned_product_rectangle_fraction": float(axis_product.mean()),
            "local_3x3x3_block_rectangle_count": int(local_span2.sum()),
            "local_3x3x3_block_rectangle_fraction": float(local_span2.mean()),
            "distinct_primitive_side_directions": len(dirs),
            "most_common_primitive_direction": list(max_dir),
            "most_common_direction_side_count": int(max_count),
            "most_common_direction_side_fraction": float(max_count / (2 * len(rows))),
            "top_10_primitive_directions": [
                {"direction": list(k), "side_count": int(v), "side_fraction": float(v / (2 * len(rows)))}
                for k, v in dirs.most_common(10)
            ],
        },
    }


def sweep_cut(rows: np.ndarray, degree: np.ndarray, order: np.ndarray) -> dict:
    n = len(degree)
    pos = np.empty(n, dtype=np.int64); pos[order] = np.arange(n)
    rp = pos[rows]
    lo, hi = rp.min(axis=1), rp.max(axis=1)
    diff = np.zeros(n + 1, dtype=np.int64)
    np.add.at(diff, lo, 1); np.add.at(diff, hi, -1)
    crossing = np.cumsum(diff)[:-1]
    volume_prefix = np.cumsum(degree[order])
    total = int(volume_prefix[-1])
    denom = np.minimum(volume_prefix, total - volume_prefix)
    allowed = (np.arange(n) >= max(0, n // 10 - 1)) & (np.arange(n) < n - n // 10) & (denom > 0)
    ratio = np.full(n, np.inf)
    ratio[allowed] = crossing[allowed] / denom[allowed]
    k = int(np.argmin(ratio))
    return {
        "balanced_vertex_count": k + 1,
        "crossing_rectangles": int(crossing[k]),
        "smaller_incidence_volume": int(denom[k]),
        "crossing_per_smaller_incidence_volume": float(ratio[k]),
    }


def coordinate_cut_attacks(vs: np.ndarray, rows: np.ndarray, degree: np.ndarray) -> list[dict]:
    out = []
    for axis, name in enumerate("xyz"):
        order = np.lexsort((np.arange(len(vs)), vs[:, axis]))
        x = sweep_cut(rows, degree, order)
        k = x["balanced_vertex_count"]
        x.update({"axis": name, "threshold_left_max": int(vs[order[k - 1], axis]),
                  "threshold_right_min": int(vs[order[k], axis]) if k < len(vs) else None})
        out.append(x)
    return out


def tarjan_incidence(n: int, rows: np.ndarray) -> dict:
    total = n + len(rows)
    adj = [[] for _ in range(total)]
    for r, row in enumerate(rows):
        node = n + r
        for v in map(int, row): adj[node].append(v); adj[v].append(node)
    sys.setrecursionlimit(max(100_000, 3 * total))
    disc = [-1] * total; low = [0] * total; parent = [-1] * total
    arts = set(); bridges = []; clock = 0
    def dfs(u: int):
        nonlocal clock
        disc[u] = low[u] = clock; clock += 1; children = 0
        for v in adj[u]:
            if disc[v] == -1:
                parent[v] = u; children += 1; dfs(v); low[u] = min(low[u], low[v])
                if parent[u] == -1 and children > 1: arts.add(u)
                if parent[u] != -1 and low[v] >= disc[u]: arts.add(u)
                if low[v] > disc[u]: bridges.append((u, v))
            elif v != parent[u]:
                low[u] = min(low[u], disc[v])
    components = 0
    for u in range(total):
        if disc[u] == -1: components += 1; dfs(u)
    return {
        "incidence_components": components,
        "articulation_velocity_vertices": sum(u < n for u in arts),
        "articulation_rectangle_nodes": sum(u >= n for u in arts),
        "incidence_bridges": len(bridges),
        "hinge_tree_attack_passed_no_articulation_or_bridge": not arts and not bridges and components == 1,
    }


def polynomial_fit(vs: np.ndarray, f: np.ndarray, max_degree: int) -> dict:
    scale = float(np.max(np.abs(vs)))
    w = vs.astype(np.float64) / scale
    exps = []
    for a in range(max_degree + 1):
        for b in range(max_degree + 1 - a):
            for c in range(max_degree + 1 - a - b): exps.append((a, b, c))
    X = np.column_stack([(w[:, 0] ** a) * (w[:, 1] ** b) * (w[:, 2] ** c) for a, b, c in exps])
    coef, *_ = np.linalg.lstsq(X, f, rcond=None)
    pred = X @ coef
    den = float(np.dot(f - f.mean(), f - f.mean()))
    r2 = 1.0 - float(np.dot(f - pred, f - pred)) / den if den else 1.0
    top = np.argsort(np.abs(coef))[::-1][:10]
    return {
        "max_total_degree": max_degree,
        "term_count": len(exps),
        "unweighted_R2": r2,
        "top_coefficients_scaled_coordinates": [
            {"exponents_xyz": list(exps[i]), "coefficient": float(coef[i])} for i in top
        ],
    }


def additive_product_fit(f: np.ndarray, side: int) -> dict:
    t = f.reshape((side, side, side))
    grand = t.mean()
    fit = t.mean(axis=(1, 2))[:, None, None] + t.mean(axis=(0, 2))[None, :, None] + t.mean(axis=(0, 1))[None, None, :] - 2 * grand
    den = float(np.sum((t - grand) ** 2))
    r2 = 1.0 - float(np.sum((t - fit) ** 2)) / den if den else 1.0
    unfolds = [t.reshape(side, -1), np.moveaxis(t, 1, 0).reshape(side, -1), np.moveaxis(t, 2, 0).reshape(side, -1)]
    rank1 = []
    for mat in unfolds:
        s = np.linalg.svd(mat, compute_uv=False)
        rank1.append(float(s[0] ** 2 / np.dot(s, s)) if np.dot(s, s) else 1.0)
    return {"axis_additive_ANOVA_R2": r2, "rank1_energy_fraction_by_axis_unfolding": rank1}


def slab_and_boundary(vs: np.ndarray, rows: np.ndarray, degree: np.ndarray,
                      xnorm: np.ndarray, m: int) -> dict:
    mass = xnorm * xnorm
    mass /= mass.sum()
    boundary = np.any(np.abs(vs) == m, axis=1)
    layers = {}
    radius = np.max(np.abs(vs), axis=1)
    for k in range(min(3, m + 1)):
        layers[str(k)] = float(mass[radius == m - k].sum())
    slabs = []
    for axis, name in enumerate("xyz"):
        vals = list(range(-m, m + 1))
        slice_mass = [float(mass[vs[:, axis] == t].sum()) for t in vals]
        width = min(3, len(vals))
        window = [sum(slice_mass[i:i + width]) for i in range(len(vals) - width + 1)]
        best = int(np.argmax(window))
        inside = (vs[:, axis] >= vals[best]) & (vs[:, axis] <= vals[best + width - 1])
        internal_rows = np.all(inside[rows], axis=1)
        slabs.append({
            "axis": name,
            "max_single_plane_soft_mass": max(slice_mass),
            "best_three_layer_soft_mass": float(window[best]),
            "best_three_layer_interval": [vals[best], vals[best + width - 1]],
            "rectangles_entirely_in_best_slab": int(internal_rows.sum()),
            "rectangles_entirely_in_best_slab_fraction": float(internal_rows.mean()),
        })
    top = np.argsort(mass)[::-1][:20]
    return {
        "boundary_soft_mass": float(mass[boundary].sum()),
        "boundary_vertex_fraction": float(boundary.mean()),
        "outer_layer_soft_mass_by_inward_offset": layers,
        "slab_attacks": slabs,
        "top_20_soft_vertices": [{"index": int(i), "coordinate": vs[i].tolist(), "mass": float(mass[i]), "degree": int(degree[i])} for i in top],
    }


def analyze_one(path: Path) -> dict:
    obj, vs, rows = load_candidate(path)
    n, m = len(vs), int(obj["m"])
    expected = n - 5
    if int(obj["exact_f2_rank"]) != expected:
        raise ValueError("candidate is not a surviving exact-F2-full candidate")
    degree = incidence_degrees(n, rows)
    x = np.asarray(obj["soft_vector_normalized_coordinates"], dtype=np.float64)
    f = np.zeros(n); f[degree > 0] = x[degree > 0] / np.sqrt(degree[degree > 0])
    # Independently recompute the stored Rayleigh singular value.
    residual = f[rows[:, 0]] + f[rows[:, 1]] - f[rows[:, 2]] - f[rows[:, 3]]
    rayleigh_sigma = 0.5 * float(np.linalg.norm(residual) / np.linalg.norm(x))
    Y = np.sqrt(degree)[:, None] * mode_matrix(vs)
    constraint_residual = np.linalg.norm(Y.T @ x)

    geom = rectangle_geometry(vs, rows)
    soft_order = np.argsort(f, kind="stable")
    soft_cut = sweep_cut(rows, degree, soft_order)
    degree_order = np.argsort(degree, kind="stable")
    degree_cut = sweep_cut(rows, degree, degree_order)
    mass = x * x; mass /= mass.sum()
    high = degree >= np.quantile(degree, 0.95)
    low = degree <= 2
    subfamilies = []
    for name, mask in [
        ("coordinate_plane", geom["coordinate_plane_mask"]),
        ("single_axis_product_KxK", geom["axis_product_mask"]),
        ("local_3x3x3_blocks", geom["local_span2_mask"]),
    ]:
        subrows = rows[mask]
        rank = f2_rank(subrows, n) if len(subrows) else 0
        subfamilies.append({
            "name": name, "rectangle_count": int(len(subrows)), "f2_rank": int(rank),
            "extra_kernel_lower_bound_over_F2_vs_target": int(expected - rank),
        })

    result = {
        "schema": "elastic_rectangle_adversarial_analysis.v1",
        "created_utc": utc_now(),
        "candidate_file": path.name,
        "candidate_id": obj["candidate_id"],
        "candidate_sha256": obj["candidate_sha256"],
        "m": m,
        "vertex_count": n,
        "rectangle_count": len(rows),
        "stored_normalized_gap_sigma": obj["normalized_spectrum"]["gap_singular_value"],
        "recomputed_soft_vector_rayleigh_sigma": rayleigh_sigma,
        "soft_vector_known_constraint_residual_l2": float(constraint_residual),
        "geometry_and_single_direction_attack": geom["summary"],
        "restricted_family_exact_F2_attacks": subfamilies,
        "two_large_blocks_sparse_cut_attack": {
            "soft_sweep": soft_cut,
            "degree_sweep": degree_cut,
            "coordinate_sweeps": coordinate_cut_attacks(vs, rows, degree),
        },
        "hinge_tree_long_chain_cycle_attack": {
            **tarjan_incidence(n, rows),
            "two_section_diameter_lower_bound": candidate_basic_stats(vs, rows, m)["two_sweep_diameter_lower_bound"],
            "incidence_bipartite_cycle_rank": candidate_basic_stats(vs, rows, m)["incidence_bipartite_cycle_rank"],
        },
        "boundary_and_narrow_slab_attack": slab_and_boundary(vs, rows, degree, x, m),
        "high_degree_core_low_degree_leaf_attack": {
            "max_degree": int(degree.max()), "min_degree": int(degree.min()),
            "vertices_degree_le_2": int(low.sum()), "soft_mass_degree_le_2": float(mass[low].sum()),
            "top_five_percent_degree_threshold": int(np.quantile(degree, 0.95)),
            "top_degree_set_vertex_count": int(high.sum()), "top_degree_set_soft_mass": float(mass[high].sum()),
        },
        "ruled_carrier_KxK_product_attack": additive_product_fit(f, 2 * m + 1),
        "near_polynomial_mode_attack": {
            "degree_2_fit": polynomial_fit(vs, f, 2),
            "degree_3_fit": polynomial_fit(vs, f, 3),
        },
        "diagnosis_policy": "large boundary/slab mass => boundary-localized; small sweep ratio => block drift; high degree-set mass => core/leaf; high polynomial R2 => near-polynomial; high product R2/rank1 => ruled/product carrier; otherwise unresolved distributed structural mode",
        "environment": environment(),
        "script_sha256": file_sha256(__file__),
    }
    features = {
        "boundary": result["boundary_and_narrow_slab_attack"]["boundary_soft_mass"] / max(1e-12, result["boundary_and_narrow_slab_attack"]["boundary_vertex_fraction"]),
        "block_drift": 1.0 / max(1e-12, soft_cut["crossing_per_smaller_incidence_volume"]),
        "near_cubic": result["near_polynomial_mode_attack"]["degree_3_fit"]["unweighted_R2"],
        "product": max(result["ruled_carrier_KxK_product_attack"]["rank1_energy_fraction_by_axis_unfolding"]),
        "core": result["high_degree_core_low_degree_leaf_attack"]["top_degree_set_soft_mass"] / max(1 / n, high.mean()),
    }
    result["automatic_soft_mode_diagnosis"] = max(features, key=features.get)
    result["diagnostic_feature_scores_not_probabilities"] = features
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("candidates", nargs="*", type=Path)
    ap.add_argument("--candidate-dir", type=Path)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--summary", type=Path, required=True)
    args = ap.parse_args()
    paths = list(args.candidates)
    if args.candidate_dir:
        paths.extend(sorted(args.candidate_dir.glob("*.json")))
    paths = sorted(set(paths))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    records, skipped, failures = [], [], []
    for path in paths:
        try:
            obj, vs, _ = load_candidate(path)
            if int(obj["exact_f2_rank"]) != len(vs) - 5:
                skipped.append({"candidate_file": path.name, "candidate_id": obj["candidate_id"], "reason": "not exact-F2-full; failed before surviving-candidate attack stage"})
                continue
            result = analyze_one(path)
            out = args.output_dir / f"{result['candidate_id']}.json"
            atomic_json(out, result)
            records.append({
                "candidate_id": result["candidate_id"], "output_file": out.name,
                "gap_sigma": result["stored_normalized_gap_sigma"],
                "rayleigh_sigma": result["recomputed_soft_vector_rayleigh_sigma"],
                "diagnosis": result["automatic_soft_mode_diagnosis"],
            })
            print(f"{result['candidate_id']}: gap={result['stored_normalized_gap_sigma']:.6g} diagnosis={result['automatic_soft_mode_diagnosis']}")
        except Exception as exc:
            failures.append({"candidate_file": path.name, "error_type": type(exc).__name__, "error": str(exc)})
            print(f"FAILED {path}: {type(exc).__name__}: {exc}", file=sys.stderr)
    summary = {
        "schema": "elastic_rectangle_attack_run.v1", "created_utc": utc_now(),
        "command": [Path(sys.argv[0]).name, *sys.argv[1:]],
        "input_candidate_count": len(paths), "surviving_candidates_attacked": len(records),
        "pre_attack_non_survivors_skipped": skipped, "failures": failures, "records": records,
        "all_surviving_candidates_attacked_without_failure": not failures,
        "environment": environment(), "script_sha256": file_sha256(__file__),
    }
    atomic_json(args.summary, summary)
    print(f"attacked={len(records)} skipped={len(skipped)} failures={len(failures)} summary={args.summary}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
